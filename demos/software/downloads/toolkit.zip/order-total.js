// Demo uses USD-style two-decimal amounts; all calculations use integer cents.
function cents(value) {
  if (typeof value !== 'string' || !/^\d+(?:\.\d{1,2})?$/.test(value)) {
    throw new TypeError('Amounts must be nonnegative decimal strings with at most two fractional digits');
  }
  const [whole, fraction = ''] = value.split('.');
  const result = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  if (!Number.isSafeInteger(result)) throw new RangeError('Amount exceeds safe integer range');
  return result;
}

export function orderTotal(lines) {
  if (!Array.isArray(lines)) throw new TypeError('Lines must be an array');
  let total = 0;
  for (const line of lines) {
    if (!line || !Number.isSafeInteger(line.quantity) || line.quantity < 1) {
      throw new TypeError('Quantity must be a positive safe integer');
    }
    const next = total + cents(line.unitPrice) * line.quantity + cents(line.shipping);
    if (!Number.isSafeInteger(next)) throw new RangeError('Total exceeds safe integer range');
    total = next;
  }
  return `${Math.floor(total / 100)}.${String(total % 100).padStart(2, '0')}`;
}

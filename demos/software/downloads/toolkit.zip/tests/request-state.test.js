import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {requestTrace as before} from '../samples/request-state/before.js';
import {requestTrace as after} from '../samples/request-state/after.js';

const contract = JSON.parse(readFileSync(new URL('../samples/request-state/contract.json', import.meta.url)));
test('same request-state fixture reproduces stale results and verifies repair', () => {
  let failures = 0;
  for (const fixture of contract.cases) {
    assert.deepEqual(after(...fixture.args), fixture.expected.value, fixture.name);
    if (JSON.stringify(before(...fixture.args)) !== JSON.stringify(fixture.expected.value)) failures++;
  }
  assert.equal(failures, 5);
});
test('request trace preserves inputs and object payloads', () => {
  const payload = Object.freeze({items: Object.freeze(['fictional'])});
  const events = Object.freeze([Object.freeze({type: 'start', id: 1}), Object.freeze({type: 'success', id: 1, data: payload})]);
  assert.equal(after(events).data, payload);
  assert.equal(events[0].type, 'start');
});
test('invalid event sequences refuse explicitly', () => {
  assert.throws(() => after(null), /Events must be an array/);
  for (const event of [null, {type: 'unknown', id: 1}, {type: 'start', id: 0},
    {type: 'start', id: 1.5}, {type: 'start', id: Number.MAX_SAFE_INTEGER + 1},
    {type: 'failure', id: 1, error: null}, {type: 'success', id: 1}]) {
    assert.throws(() => after([event]), /Invalid request event/);
  }
});
test('unstarted future completion cannot replace active state', () => {
  assert.deepEqual(after([{type:'start', id:1}, {type:'success', id:2, data:'unstarted'}]),
    {requestId:1, status:'loading', data:null, error:null});
});

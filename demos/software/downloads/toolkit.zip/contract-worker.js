import { parentPort, workerData } from 'node:worker_threads';
import { isDeepStrictEqual } from 'node:util';

// One fresh module instance per case. This is execution isolation, not a sandbox.
try {
  const module = await import(workerData.moduleUrl);
  const fn = module[workerData.exportName];
  if (typeof fn !== 'function') throw new Error('Named export is not a function');
  let actual, value, functionError;
  try {
    value = await fn(...workerData.test.args);
  } catch (error) {
    functionError = { name: String(error?.name ?? 'Error'), message: String(error?.message ?? error) };
    if (functionError.name.length > 200 || functionError.message.length > 2000) {
      parentPort.postMessage({ status: 'execution-error', diagnostic: 'Function exception exceeds supported name/message limits' });
      process.exit(0);
    }
  }
  if (functionError) {
    actual = { error: functionError };
    const passed = Object.hasOwn(workerData.test.expected, 'error') &&
      isDeepStrictEqual(actual.error, workerData.test.expected.error);
    parentPort.postMessage({ status: passed ? 'passed' : 'failed', actual });
  } else {
    // Only JSON-compatible return values are part of this contract format.
    function jsonValue(v, depth = 0) {
      if (depth > 30) return false;
      if (v === null || typeof v === 'string' || typeof v === 'boolean') return true;
      if (typeof v === 'number') return Number.isFinite(v);
      if (Array.isArray(v)) return v.every(x => jsonValue(x, depth + 1));
      return typeof v === 'object' && Object.getPrototypeOf(v) === Object.prototype &&
        Object.values(v).every(x => jsonValue(x, depth + 1)) &&
        Reflect.ownKeys(v).every(k => typeof k === 'string');
    }
    const serialized = jsonValue(value) ? JSON.stringify(value) : undefined;
    if (!serialized || Buffer.byteLength(serialized, 'utf8') > 32768 || !isDeepStrictEqual(value, JSON.parse(serialized))) {
      parentPort.postMessage({ status: 'execution-error', diagnostic: 'Return value is unsupported or exceeds 32 KB' });
    } else {
      actual = { value, type: value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value };
      const passed = Object.hasOwn(workerData.test.expected, 'value') &&
        isDeepStrictEqual(value, workerData.test.expected.value);
      parentPort.postMessage({ status: passed ? 'passed' : 'failed', actual });
    }
  }
} catch {
  // Import errors are not expected function exceptions; never count them as passes.
  parentPort.postMessage({ status: 'execution-error', diagnostic: 'Module import or named export failed' });
}

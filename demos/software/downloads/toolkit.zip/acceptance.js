import { orderTotal as original } from './before/order-total.js';
import { orderTotal as repaired } from './order-total.js';

// The same observable contract is checked against both implementations.
export function checkAcceptance(orderTotal) {
  const cases = [
    { name: 'multiple form lines', lines: [
      { unitPrice: '12.50', quantity: 2, shipping: '3.00' },
      { unitPrice: '4.99', quantity: 1, shipping: '0.00' }
    ], expected: '32.99' },
    { name: 'decimal cents', lines: [
      { unitPrice: '0.10', quantity: 3, shipping: '0.20' }
    ], expected: '0.50' },
    { name: 'empty order', lines: [], expected: '0.00' }
  ];
  return cases.map(({ name, lines, expected }) => {
    const actual = orderTotal(lines);
    return { name, expected, actual, passed: actual === expected };
  });
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], 'file:').href) {
  const mode = process.argv[2];
  if (!['before', 'after'].includes(mode) || process.argv.length !== 3) {
    console.error('Usage: node acceptance.js before|after');
    process.exitCode = 1;
  } else {
    const results = checkAcceptance(mode === 'before' ? original : repaired);
    console.log(JSON.stringify({ synthetic: true, mode, results }, null, 2));
    process.exitCode = results.every(result => result.passed) ? 0 : 2;
  }
}

"""Exercise the shipped CLI from source ZIP through recipient repair reruns."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def run(args, cwd, expected=0):
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True, timeout=120)
    if result.returncode != expected:
        raise RuntimeError(f'{args}: expected exit {expected}, got {result.returncode}\n'
                           f'{result.stdout}\n{result.stderr}')
    if expected != 0:
        if result.stdout or 'SHA256 mismatch' not in result.stderr:
            raise RuntimeError('Incorrect pin did not produce the expected refusal')
        return None
    return json.loads(result.stdout)


def main(output):
    output = Path(output).absolute()
    output.mkdir(mode=0o700)
    archive = output / 'software-fix-demo.zip'
    packaged = run([sys.executable, 'package_demo.py', str(archive)], ROOT)
    run([sys.executable, 'verify_demo.py', str(archive), packaged['sha256']], ROOT)
    # Verify with source-side trusted code before extracting any delivered file.
    recipient = output / 'source-recipient'
    with zipfile.ZipFile(archive) as source:
        source.extractall(recipient)
    node_tests = sorted(str(path.relative_to(recipient)) for path in (recipient / 'tests').glob('*.test.js'))
    subprocess.run(['node', '--test', *node_tests], cwd=recipient, check=True, timeout=120)
    subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py'],
                   cwd=recipient, check=True, timeout=120)
    fixtures = [
        ('order-total', 'contracts/order-total.json', 'before/order-total.js', 'order-total.js'),
        ('request-state', 'samples/request-state/contract.json',
         'samples/request-state/before.js', 'samples/request-state/after.js'),
    ]
    receipts = {}
    for name, contract, before, after in fixtures:
        inspected = run(['node', 'contract-review.js', '--inspect', contract], recipient)
        pin = hashlib.sha256((recipient / contract).read_bytes()).hexdigest()
        # The inspection output must bind the exact bytes used by release.
        if inspected['contractSha256'] != pin:
            raise RuntimeError('Inspection did not bind fixture bytes')
        release = output / name
        receipt = run([sys.executable, 'release_repair.py', contract, before, after,
                       str(release), pin], recipient)
        if receipt['complete'] is not True or receipt['customerAccepted'] is not False:
            raise RuntimeError('Unexpected completion/acceptance receipt')
        run([sys.executable, str(ROOT / 'handoff_archive.py'), 'verify',
             str(release / 'handoff.zip'), receipt['archiveSha256']], ROOT)
        handoff_recipient = output / (name + '-recipient')
        with zipfile.ZipFile(release / 'handoff.zip') as handoff:
            handoff.extractall(handoff_recipient)
        actual = run(['node', 'contract-review.js', '--contract-sha256', pin,
                      'contract.json', 'before/module.mjs', 'after/module.mjs'], handoff_recipient)
        saved = json.loads((handoff_recipient / 'report.json').read_text())
        if actual != saved:
            raise RuntimeError('Recipient results differ from delivered evidence')
        # Confirm the actual shipped CLI fails closed for an incorrect pin.
        run([sys.executable, 'release_repair.py', contract, before, after,
             str(output / (name + '-wrong-pin')), '0' * 64], recipient, expected=1)
        if list((output / (name + '-wrong-pin')).iterdir()):
            raise RuntimeError('Incorrect pin left execution or completion evidence')
        receipts[name] = receipt
    evidence = {'sourcePackage': packaged, 'fixtures': receipts,
                'sourceRecipientTestsPassed': True, 'recipientRerunsMatched': True,
                'customerAccepted': False}
    (output / 'E2E.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps(evidence, sort_keys=True))


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 tools/ci_e2e.py NEW_OUTPUT_DIRECTORY')
    main(sys.argv[1])

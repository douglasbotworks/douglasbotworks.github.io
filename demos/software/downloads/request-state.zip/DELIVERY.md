# Scoped standalone JavaScript repair evidence

This package contains the supplied original, repair and contract. It establishes fixture results only; it is not customer acceptance.

After reviewing the trusted source, run with Node 18+: `node contract-review.js --contract-sha256 669c602d28c8615572a28307d697fc6b238489fbc8e26f320f53c55bc17c98ce contract.json before/module.mjs after/module.mjs > recipient-report.json`. Expected exit: 0. Compare the contract/module hashes and every case result to report.json. Rerun reports need not have identical bytes across Node versions.

change.diff is an informational unified diff between the two supplied files. It is not an automatically applicable customer-repository patch. Review callers and replace the agreed module through the authorized project workflow.

Only standalone ESM files are supported. Relative dependencies, configuration, shared state, browser acceptance, deployment, external-service tests and payment are outside this package. Modules run from relocated .mjs files. Workers are not a security sandbox; run only inspected authorized code. Original paths and credentials are not recorded. No customer source is uploaded.

MANIFEST.json records exact file hashes and sizes; it is not a signature. Preserve the agreed scope, original project revision, integration regression results and actual customer acceptance separately.

# Reproducible scoped JavaScript repair review

This dependency-free Node 18+ command compares two **authorized, trusted** local
modules against one JSON contract. It is service-delivery tooling, not a claim of
customer work, payment, a security audit or production acceptance.

```sh
node contract-review.js contracts/order-total.json before/order-total.js order-total.js > review.json
```

The supplied example is fictional. Its original fails three cases and its repair
passes all three; one case exposes the numeric-versus-string return type change.
Review actual callers before accepting that change in a real project.

Before using a customer module, agree the one-defect scope, access authorization,
expected behavior and types, exclusions, price/payment channel, and acceptance
decision maker. Obtain sanitized fixtures. Inspect code and dependencies before
running them. Do not use this runner to execute unknown downloads or to collect
credentials, production customer data or personal records.

## Inspect before executing

`node contract-review.js --inspect contract.json` checks the same bounded file,
UTF-8, JSON ambiguity and contract shape rules without opening implementation
modules or creating workers. It prints the exact contract hash/byte length,
export, deadline and case names/count. Valid input exits 0; invalid input exits 1
with stderr and no JSON report. This helps both parties identify a fixture before
an authorized execution. It does not establish commercial agreement, reproducibility,
repair correctness or acceptance. The hash covers the inspected bytes only; compare
it with the later review hash because the file can change between commands.

## Contract format

The top-level fields must be exactly `version`, `exportName`, `timeoutMs` and
`cases`. Version is integer 1, the named export must be a function, timeout is
100–10000 ms, and 1–50 cases are allowed. Each case has exactly `name`, `args`
and `expected`. Names are nonempty and unique. `args` is an array of positional
JSON arguments; to pass an array as the first argument, nest it inside `args`.

Expected return example:

```json
{"name":"empty order","args":[[]],"expected":{"value":"0.00"}}
```

Expected function exception/rejection example:

```json
{"name":"invalid input","args":[null],"expected":{"error":{"name":"TypeError","message":"Lines must be an array"}}}
```

Values compare deeply with exact types; object key order is immaterial. Return
values must round-trip as JSON without loss. Undefined, NaN/Infinity, dates,
class instances, sparse arrays, cyclic data and values over 32 KB are unsupported.
Error names/messages compare exactly; names are limited to 200 JavaScript
string code units and messages to 2000. Oversized expected errors are rejected
before module access; oversized actual errors are execution failures, never
truncated into matching prefixes. The 32 KB return limit counts serialized
UTF-8 bytes. Fixtures must be UTF-8 JSON, not executable
expressions. Duplicate object keys are rejected at every level, including keys
written with equivalent Unicode escapes. JSON nesting is limited to 30 levels,
and exponent overflow is rejected before module execution. Contracts
are limited to 256 KB and entry modules to 512 KB. Malformed UTF-8 is rejected
without replacement characters. Inputs are opened nonblocking, checked as regular
files through their descriptors, and read with a fixed byte bound; FIFOs are
rejected promptly. Symlinks to regular files remain supported. These checks do
not freeze filesystem contents or contain implementation side effects.

## What the result means

- Exit 0 / `verified: true`: at least one original case fails, all repaired cases
  pass, and neither implementation has an execution error.
- Exit 2 / `verified: false`: comparison ran but the original did not reproduce
  a defect, or the repair still has a failing case.
- Exit 1: invalid input or execution failure. Per-case timeouts, missing exports,
  import errors and unsupported outputs never count as verified repairs. Where
  execution reached the cases, JSON retains the diagnostic and remaining results.

The report records expected/actual values and types, case counts, Node version,
and SHA256 of exact contract and entry-module bytes. Contract and entry files are
rechecked after execution; changing one during review invalidates the run. Hashes are not
signatures, and do not cover transitive dependencies or runtime state. Freeze the
whole reviewed checkout and retain its revision with the report. A changed
dependency requires a new review. Do not edit expected output to make a patch pass
without a separately agreed contract change.

Each case uses a fresh worker/module instance and fresh arguments. Async results
are awaited; timeout includes import/startup. Workers are terminated before the
next case. Stdout/stderr from implementations are discarded so the report remains
valid JSON. Workers receive an empty environment and bounded V8 heap, but still
run with current-user filesystem and network access. **This is not a security
sandbox** and does not constrain native allocations or subprocess descendants.
Modules requiring environment configuration, shared state, browser APIs or
external services need a separate approved test setup. A timeout gives a caller
deadline, not rollback of side effects.

## Delivery checklist

1. Preserve the original revision and failing report, along with the agreed JSON
   contract and runtime version.
2. Make the bounded repair; run the same contract and inspect every result.
3. Check callers, existing regression suite and relevant runtime integration.
4. Deliver patch/diff, exact report, commands, revision/hash, scope and remaining
   limitations. Obtain actual customer acceptance through the approved channel.

The fixed demo package includes this command, worker, example contract and tests.
Its recipient verifier checks inventory/bytes without running JavaScript; running
the example after verification is a separate step. Do not publish customer
modules or reports in the public sales site.

## Assemble a standalone handoff

`python3 deliver_repair.py contract.json before.js after.js NEW_DIRECTORY` reads
bounded regular-file snapshots, copies them as before/module.mjs and
after/module.mjs, and runs the shipped review command from a temporary sibling
directory with an empty environment. Node and Git must be available. The supplied
modules must be standalone ESM; dependencies are deliberately not discovered or
copied. A failed comparison, missing dependency, changed input or diff failure
refuses the requested delivery. Existing output is never overwritten.

On POSIX, delivery directories use mode 0700 and files use mode 0600, even
with a permissive process umask. Review sharing permissions when moving or
extracting an archive; these local modes do not establish recipient access.

The resulting ten-file directory includes exact modules and contract, runtime
runner, report, diff, instructions and manifest. The manifest is written last;
interrupted writes are incomplete. Failed stages and their diagnostics are
retained locally. Review them as private customer material; nothing is uploaded.
Hashes establish consistency, not identity. Keep actual project revision, agreed
commercial scope, caller tests and customer acceptance separately. The diff uses
the fixed before/after paths and is informational; applying it to a customer
repository requires mapping its path to the agreed module and checking callers.

Expected values must round-trip through JSON exactly and serialize within 32768
UTF-8 bytes, matching the return-value bound. Inspection and review reject
oversized expectations and negative zero (including nested negative zero) before
module reads. This checks representability, not whether the function can meet
the agreed result. Argument values retain their existing JSON semantics.


Pin an inspected fixture when executing or delivering it:

```sh
node contract-review.js --contract-sha256 HASH contract.json before.js after.js
python3 deliver_repair.py --contract-sha256 HASH contract.json before.js after.js NEW_DIRECTORY
```

Replace HASH with the exact lowercase 64-character SHA256 from `--inspect`,
retained through the agreed channel. Both commands refuse a mismatch before
reading implementation modules; the handoff builder also refuses before creating
its diagnostic stage. A whitespace-only contract edit changes the hash and requires
fresh inspection. The pin is optional for backwards compatibility; an unpinned
command does not establish that these were the previously inspected bytes.
Every new handoff records a pinned recipient rerun command in DELIVERY.md and
pins its internal execution to its contract snapshot. The pin establishes byte
identity only, not sender identity, commercial agreement or customer acceptance.

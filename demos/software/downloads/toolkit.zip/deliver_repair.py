"""Assemble evidence for a trusted, standalone ESM repair; never submit it."""
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def snapshot(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError('Input must be a regular file within the size limit')
        chunks, length = [], 0
        while length <= limit:
            chunk = os.read(fd, min(65536, limit + 1 - length))
            if not chunk:
                break
            chunks.append(chunk)
            length += len(chunk)
        if length > limit:
            raise ValueError('Input exceeds size limit')
        return b''.join(chunks)
    finally:
        os.close(fd)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def deliver(contract, original, repaired, output, expected_contract_sha256=None):
    output = Path(output).absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Output must not exist')
    node, git = shutil.which('node'), shutil.which('git')
    if not node or not git:
        raise ValueError('Node and Git must be available')
    contract_bytes = snapshot(contract, 262144)
    if expected_contract_sha256 is not None:
        if not isinstance(expected_contract_sha256, str) or not re.fullmatch(r'[a-f0-9]{64}', expected_contract_sha256):
            raise ValueError('Expected contract SHA256 must be 64 lowercase hexadecimal characters')
        if digest(contract_bytes) != expected_contract_sha256:
            raise ValueError('Contract SHA256 mismatch; no implementation modules read or executed')
    contract_sha256 = digest(contract_bytes)
    payload = {
        'contract.json': contract_bytes,
        'contract-review.js': snapshot(ROOT / 'contract-review.js', 250000),
        'contract-worker.js': snapshot(ROOT / 'contract-worker.js', 250000),
        'package.json': b'{"private":true,"type":"module"}\n',
    }
    # Keep failed stages for diagnosis; only a completed, verified comparison
    # is copied to the requested output. No customer source goes to a network.
    stage = Path(tempfile.mkdtemp(prefix='tmp-repair-', dir=output.parent))
    for name, data in payload.items():
        path = stage / name
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        path.write_bytes(data)
    inspected = subprocess.run([node, 'contract-review.js', '--inspect', 'contract.json'], cwd=stage, env={}, capture_output=True, timeout=30)
    if inspected.returncode != 0:
        raise ValueError(f'Repair not verified: invalid contract; inspect retained stage {stage}')
    if json.loads(inspected.stdout).get('contractSha256') != contract_sha256:
        raise ValueError('Contract changed during inspection')
    for name, source in [('before/module.mjs', original), ('after/module.mjs', repaired)]:
        data = snapshot(source, 524288)
        payload[name] = data
        path = stage / name
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        path.write_bytes(data)
    command = [node, 'contract-review.js', '--contract-sha256', contract_sha256, 'contract.json', 'before/module.mjs', 'after/module.mjs']
    with (stage / 'report.json').open('xb') as report_file, (stage / 'diagnostic.txt').open('xb') as diagnostic:
        run = subprocess.run(command, cwd=stage, env={}, stdout=report_file, stderr=diagnostic, timeout=1100)
    if run.returncode != 0:
        raise ValueError(f'Repair not verified (exit {run.returncode}); inspect retained stage {stage}')
    report_bytes = snapshot(stage / 'report.json', 8000000)
    report = json.loads(report_bytes)
    if report.get('verified') is not True or report.get('contractSha256') != digest(payload['contract.json']):
        raise ValueError('Report does not verify the supplied contract')
    for role in ('before', 'after'):
        matches = [entry for entry in report['implementations'] if entry['role'] == role]
        if len(matches) != 1 or matches[0]['entrySha256'] != digest(payload[f'{role}/module.mjs']):
            raise ValueError('Report does not verify the supplied module bytes')
    for name, data in payload.items():
        if snapshot(stage / name, max(len(data), 1)) != data:
            raise ValueError('Delivery input changed during verification')
    patch = subprocess.run([git, '--no-pager', 'diff', '--no-index', '--no-ext-diff', '--no-textconv',
                            '--', 'before/module.mjs', 'after/module.mjs'], cwd=stage, env={},
                           capture_output=True, timeout=30)
    if patch.returncode != 1 or not patch.stdout or len(patch.stdout) > 4000000:
        raise ValueError('Could not produce a bounded nonempty patch')
    payload['report.json'] = report_bytes
    payload['change.diff'] = patch.stdout
    payload['DELIVERY.md'] = (
        '# Scoped standalone JavaScript repair evidence\n\n'
        'This package contains the supplied original, repair and contract. '
        'It establishes fixture results only; it is not customer acceptance.\n\n'
        'After reviewing the trusted source, run with Node 18+: `node contract-review.js '
        f'--contract-sha256 {contract_sha256} contract.json before/module.mjs after/module.mjs > recipient-report.json`. '
        'Expected exit: 0. Compare the contract/module hashes and every case result '
        'to report.json. Rerun reports need not have identical bytes across Node versions.\n\n'
        'change.diff is an informational unified diff between the two supplied files. '
        'It is not an automatically applicable customer-repository patch. Review callers '
        'and replace the agreed module through the authorized project workflow.\n\n'
        'Only standalone ESM files are supported. Relative dependencies, configuration, '
        'shared state, browser acceptance, deployment, external-service tests and payment '
        'are outside this package. Modules run from relocated .mjs files. Workers are '
        'not a security sandbox; run only inspected authorized code. Original paths '
        'and credentials are not recorded. No customer source is uploaded.\n\n'
        'MANIFEST.json records exact file hashes and sizes; it is not a signature. '
        'Preserve the agreed scope, original project revision, integration regression '
        'results and actual customer acceptance separately.\n'
    ).encode()
    manifest = {'version': 1, 'fixtureVerified': True, 'files': {
        name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(payload.items())}}
    payload['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    # Exclusive directory creation refuses collisions. The manifest is written last:
    # interrupted writes must not be treated as a complete handoff.
    output.mkdir(mode=0o700)
    for name, data in payload.items():
        path = output / name
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as destination:
            destination.write(data)
    return {'output': str(output), 'fixtureVerified': True, 'files': len(payload),
            'manifestSha256': digest(payload['MANIFEST.json']), 'summary': report['summary']}

if __name__ == '__main__':
    try:
        args = sys.argv[1:]
        expected = None
        if args and args[0] == '--contract-sha256':
            if len(args) < 2:
                raise ValueError('Missing contract SHA256')
            expected, args = args[1], args[2:]
        if len(args) != 4:
            raise ValueError('Usage: python3 deliver_repair.py [--contract-sha256 HASH] contract.json before.js after.js NEW_DIRECTORY')
        print(json.dumps(deliver(*args, expected_contract_sha256=expected), sort_keys=True))
    except (ValueError, OSError, KeyError, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)

import{e as h}from"../assets/html-jTtHQ-31.js";import{g as v,a as k,i as y,s as E}from"../assets/storage-m262-Hy8.js";import{M as S}from"../assets/messages-BXYArEhg.js";function w(){var s;let a=document.getElementById("save-status");a||(a=document.createElement("p"),a.id="save-status",a.setAttribute("role","status"),(s=document.getElementById("app"))==null||s.append(a)),a.textContent="Settings were not saved. Please retry."}async function o(){try{await x()}catch{const a=document.getElementById("app");if(!a)return;a.replaceChildren();const s=document.createElement("p");s.setAttribute("role","status"),s.textContent="Could not load settings or the active tab. Retry to continue.";const n=document.createElement("button");n.id="retry-load",n.textContent="Retry",n.addEventListener("click",()=>{n.disabled=!0,o()}),a.append(s,n)}}async function x(){const a=document.getElementById("app");if(!a){console.warn("Popup app root not found.");return}a.innerHTML||(a.innerHTML=`
      <div class="popup-container">
        <header class="popup-header">
          <h1 class="popup-title">Gradual Translation</h1>
          <div class="subtitle loading-pulse">Loading…</div>
        </header>
        <main class="popup-main">
          <div class="control-group skeleton-block"></div>
          <div class="divider"></div>
          <div class="status-card skeleton-block" style="height:60px"></div>
          <div class="action-buttons" style="margin-top:16px">
            <div class="skeleton-block" style="height:36px;border-radius:8px"></div>
          </div>
        </main>
      </div>
    `);const[s,n]=await Promise.all([v(),chrome.tabs.query({active:!0,currentWindow:!0})]),e=n[0],r=e!=null&&e.url?k(e.url):"";let l=null;if(e!=null&&e.id)try{const t=await chrome.runtime.sendMessage({type:"GET_TAB_STATE",tabId:e.id});l=t==null?void 0:t.state}catch(t){console.warn("Failed to query tab state:",t)}const p=e!=null&&e.url?await y(e.url,{...s,enabled:!0}):!1,m=!p,g=p;let u=p?"Enabled":"Disabled";s.siteMode==="allowlist"?u=g?"Enabled":"Disabled":s.siteMode==="blocklist"&&(u=m?"Disabled":"Enabled"),s.enabled||(u="Paused globally"),a.innerHTML=`
    <div class="popup-container">
      <header class="popup-header">
        <div>
          <h1 class="popup-title">Gradual Translation</h1>
          <div class="subtitle">Exposure: <span class="badge badge-primary">${h(s.exposure)}</span></div>
        </div>
        <span class="badge badge-primary">PROTOTYPE</span>
      </header>
      
      <main class="popup-main">
        <div class="control-group">
          <label class="switch-label">
            <span>Global Active State</span>
            <input id="enabled-toggle" type="checkbox" ${s.enabled?"checked":""} class="ios-switch" />
          </label>
        </div>

        <div class="divider"></div>

        <div class="status-card">
          <div class="status-row">
            <span class="status-label">Current Domain:</span>
            <span class="status-value highlight">${h(r||"Browser Page")}</span>
          </div>
          <div class="status-row">
            <span class="status-label">Status:</span>
            <span class="status-value">${u}</span>
          </div>
          <div class="status-row">
            <span class="status-label">Translated:</span>
            <span class="status-value">${l?l.processedCount:0} words</span>
          </div>
        </div>

        <p class="pro-card-desc">Review build. Paid upgrades are not available.</p>

        <div class="action-buttons">
          ${r?`
            <button id="toggle-host-btn" class="btn btn-secondary">
              ${m||s.siteMode==="allowlist"&&!g?"Enable on this Site":"Disable on this Site"}
            </button>
          `:""}
          ${e!=null&&e.id&&l&&l.processedCount>0?`
            <button id="undo-page-btn" class="btn btn-secondary">
              Undo All Translations
            </button>
          `:""}
          <button id="open-options" class="btn btn-primary">Open Settings</button>
        </div>
      </main>
    </div>
  `;const i=document.getElementById("enabled-toggle"),b=document.getElementById("open-options"),c=document.getElementById("toggle-host-btn"),d=document.getElementById("undo-page-btn");i==null||i.addEventListener("change",async()=>{i.disabled=!0;try{const t=await v();await E({...t,enabled:i.checked},t),await o()}catch{i.checked=s.enabled,i.disabled=!1,w()}}),c==null||c.addEventListener("click",async()=>{if(r){c.disabled=!0;try{const t=await v(),f=await y(e.url,{...t,enabled:!0});await E({...t,siteOverrides:{...t.siteOverrides,[r]:!f}},t),await o()}catch{c.disabled=!1,w()}}}),d==null||d.addEventListener("click",async()=>{if((e==null?void 0:e.id)!==void 0){d.disabled=!0;try{const t=await chrome.runtime.sendMessage({type:S.UNDO_PAGE_MUTATIONS,pageId:"page-current",tabId:e.id});if((t==null?void 0:t.ok)!==!0||(t==null?void 0:t.restored)!==!0)throw Error("Undo failed");await o()}catch{d.textContent="Undo failed — retry",d.disabled=!1}}}),b==null||b.addEventListener("click",()=>{chrome.runtime.openOptionsPage()})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{o()}):o();

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
test('identical acceptance contract fails original and passes replacement through CLI', () => {
  const run = mode => spawnSync(process.execPath, ['acceptance.js', mode], { cwd: root, encoding: 'utf8' });
  const before = run('before');
  const after = run('after');
  assert.equal(before.status, 2);
  assert.equal(after.status, 0);
  assert.equal(before.stderr, '');
  assert.equal(after.stderr, '');
  const oldResults = JSON.parse(before.stdout).results;
  const newResults = JSON.parse(after.stdout).results;
  assert.deepEqual(oldResults.map(({ name, expected }) => ({ name, expected })),
    newResults.map(({ name, expected }) => ({ name, expected })));
  assert.ok(oldResults.every(result => !result.passed));
  assert.ok(newResults.every(result => result.passed));
  assert.equal(newResults[0].actual, '32.99');
});
test('unknown mode refuses execution with a useful diagnostic', () => {
  const result = spawnSync(process.execPath, ['acceptance.js', 'unknown'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 1);
  assert.equal(result.stdout, '');
  assert.match(result.stderr, /Usage:/);
});

# Synthetic software-fix sample

The prepared GitHub Actions workflow `.github/workflows/build-e2e.yml` supports
pushes, pull requests and manual dispatch once installed. Its remote installation
requires Douglas's credential to have workflow write scope; the harness can run
locally before that setup is resolved. It checks the source Node/Python suites,
builds and verifies the source ZIP, reruns both suites from that extracted ZIP,
then releases both fictional repairs and verifies/reruns each recipient handoff.
Incorrect fixture pins must refuse before execution. Successful CI retains the
source ZIP, handoff ZIPs, receipts and `E2E.json` for 14 days. These are command-line
delivery checks; customer and browser acceptance remain unestablished.
Reproduce with `python3 tools/ci_e2e.py tmp-ci-NEW` using a fresh directory.
No dependency install, credentials or paid APIs are required.

Second independent sample: [asynchronous request state](samples/request-state/README.md)
demonstrates stale-response, cancellation and duplicate-completion repairs against
the same fictional fixture. It uses the existing runner and standalone handoff,
with no React/browser/customer acceptance implied.

One-command verified release after inspecting and agreeing the fixture:

```sh
node contract-review.js --inspect contracts/order-total.json
python3 release_repair.py contracts/order-total.json before/order-total.js order-total.js NEW_DIRECTORY INSPECTED_SHA256
```

Replace INSPECTED_SHA256 with the exact hash from inspection. The required pin
is checked before implementation reads. The command reserves a private exclusive
directory, runs the standalone handoff, packages it as handoff.zip, verifies that
archive and writes RECEIPT.json last. Only a release with that receipt is complete.
It records the archive/fixture/manifest hashes and real results, with customer
acceptance explicitly false. Share only handoff.zip and its trusted digest; the
release directory also retains private execution stages. Failures retain diagnostic
files without a receipt; inspect locally and retry in a fresh directory. Existing
directories are refused. This is a convenience over the existing delivery/verifier,
with the same trusted-code and standalone-module limits. It neither submits a
repair nor collects payment. Recipients still use a separately trusted verifier
before extraction and inspect source before executing it.

Private demonstration for a proposed scoped bug-fix service. No client data,
paid APIs, dependencies, wallets or trading. This is not a real customer result.

Run `node --test tests/*.test.js` and `node demo.js` with Node 18 or newer.
The equivalent `npm test` script is provided and passes in the current worker.
Direct Node commands also work without installing dependencies.

Acceptance criterion: two fictional form-input order lines must total `32.99`.
The original function concatenates string shipping values. The patch validates
decimal inputs and sums integer cents, returning a two-decimal string.

The return type changes to a formatted decimal string; a real integration must
review callers before adopting it. Shipping is per line. This deliberately small
demo excludes taxes, discounts, refunds, multiple currencies and payment processing.

Handoff: `order-total.js` is the replacement, `before/` preserves the reproduction,
and `tests/` covers the acceptance case, exact cents, invalid inputs and overflow.
No deployment or ongoing support is included. Proposed service price and demand
remain unvalidated. Digital-product publishing is authorized; contact with clients
requires the explicit owner approval specified in the workspace instructions.

Run `node acceptance.js before` to reproduce the defect using three observable
acceptance cases (expected exit 2), then `node acceptance.js after` to check the
same cases against the replacement (expected exit 0). Each command writes JSON
with expected and actual values. Exit 1 means invalid command usage. The original
also fails the formatted-string return contract for an empty order. These are
synthetic demonstrations, not evidence of WordPress/plugin experience or browser
acceptance. The test suite separately checks invalid inputs and safe-integer limits.

Package the explicit source/test inventory with
`python3 package_demo.py /path/to/new-demo.zip`. The parent directory must exist;
existing archives are refused. The ZIP uses stable metadata and stored entries,
and includes MANIFEST.json with byte lengths and SHA256 for each source file.
The manifest establishes content consistency, not sender authenticity. No
credentials, dependencies, Git history or arbitrary directory entries are bundled.

Recipient check (using a separately trusted copy of the verifier):
`python3 verify_demo.py archive.zip expected-sha256` checks the supplied archive
digest, exact fixed inventory, ZIP CRCs and every manifest size/hash without
extracting or running the delivered JavaScript. Obtain the expected digest over
a trusted channel. A self-contained hash manifest does not authenticate a sender.
The verifier accepts only unencrypted stored ZIP members describing regular files.
Unix symlink, directory, FIFO, socket and device types, plus DOS directory flags,
are refused before extraction. Missing Unix type bits are accepted for archives
from tools that do not record them; verification never creates filesystem objects.
It limits archives to
2 MB and each member to 250 KB. Failures exit 1 with a diagnostic.
Run delivery regressions with `python3 -m unittest discover -s tests -p 'test_*.py'`.

Buyer-facing proof page: `node build-proof.js NEW_OUTPUT_DIRECTORY` produces a
three-file static site. Its displayed values come from executing both real sample
functions against the same acceptance contract; generation stops unless the
original fails and the repair passes. The page and downloadable result JSON
contain only fictional data, label the work as synthetic and describe the
proposed $150 pilot without enabling a booking or payment. No code repair or
customer delivery is implied by generating the page. The source ZIP includes both marketing builders and the reproducible CLI
end-to-end harness; generated sites remain separate outputs.

Reusable service-delivery runner: `node contract-review.js
contracts/order-total.json before/order-total.js order-total.js` checks both
modules against the same contract, including exact value types, async results and
expected errors. A verified repair requires a reproduced original failure and
all repaired cases passing. Execution errors/timeouts prevent verification.
See [CONTRACT-REVIEW.md](CONTRACT-REVIEW.md) for the format, exit codes, limitations
and delivery checklist. It executes trusted authorized code; workers are not a
security sandbox. The fixed source package now includes this runner and its tests.

Standalone repair handoff: `python3 deliver_repair.py contracts/order-total.json
before/order-total.js order-total.js NEW_DIRECTORY` snapshots the supplied files,
runs the actual contract against relocated .mjs copies, and creates an exclusive
delivery directory only if the original fails and the repair passes. It includes
original/repair, contract, runner, actual report, informational diff, instructions
and a file hash manifest. Relative dependencies are not bundled; execution errors
refuse delivery. Run only inspected, authorized standalone ESM modules. No client
submission, payment, browser or caller-integration acceptance is performed. Failed
verification stages are retained locally for diagnosis; treat their source as
private. An interrupted output without its final manifest is incomplete.

Transport an actual repair handoff with `python3 handoff_archive.py pack
NEW_DIRECTORY NEW.zip`. The command checks the exact ten-file inventory and all
manifest lengths/hashes before writing an exclusive, deterministic stored ZIP.
Extra files, unexpected directories, symlinks, incomplete manifests and changed
bytes refuse packaging. It snapshots bytes, not the filesystem; use a private
directory without concurrent writers. POSIX Python is required.

Before extracting, use a separately trusted copy of `handoff_archive.py`:
`python3 handoff_archive.py verify NEW.zip EXPECTED_SHA256`. Obtain the archive
digest through a trusted channel. This bounds reads, checks inventory, ZIP CRCs
and manifest contents, and executes no delivered JavaScript. Content consistency
does not authenticate the sender or prove fixture results. Inspect the trusted
source and rerun the contract as described in DELIVERY.md for execution evidence.
The verifier stays outside the ten-file handoff and has no third-party dependencies.

Agreed contract JSON refuses duplicate keys (including equivalent escaped names),
nonfinite numbers and nesting beyond 30 levels before reading implementation
modules. The handoff builder uses this same check and refuses ambiguous contracts.

Inspect a proposed fixture before execution with `node contract-review.js --inspect
contract.json`. This uses the same strict input checks and emits the exact hash,
export and case list without reading modules or starting workers. Compare that
hash with the subsequent review; inspection does not establish agreement or a fix.

Expected values must round-trip through JSON exactly and serialize within 32768
UTF-8 bytes, matching the return-value bound. Inspection and review reject
oversized expectations and negative zero (including nested negative zero) before
module reads. This checks representability, not whether the function can meet
the agreed result. Argument values retain their existing JSON semantics.


Pin an inspected fixture when executing or delivering it:

```sh
node contract-review.js --contract-sha256 HASH contract.json before.js after.js
python3 deliver_repair.py --contract-sha256 HASH contract.json before.js after.js NEW_DIRECTORY
```

Replace HASH with the exact lowercase 64-character SHA256 from `--inspect`,
retained through the agreed channel. Both commands refuse a mismatch before
reading implementation modules; the handoff builder also refuses before creating
its diagnostic stage. A whitespace-only contract edit changes the hash and requires
fresh inspection. The pin is optional for backwards compatibility; an unpinned
command does not establish that these were the previously inspected bytes.
Every new handoff records a pinned recipient rerun command in DELIVERY.md and
pins its internal execution to its contract snapshot. The pin establishes byte
identity only, not sender identity, commercial agreement or customer acceptance.

Build the separate public-safe request-state proof page with `node build-request-proof.js NEW_OUTPUT_DIRECTORY`. It runs the trusted fictional modules and writes HTML, the shared fixture and actual results only. No client data or source code is copied. Link it from a parent example page as `request-state/index.html`; its back link expects that layout. Partial output after a write failure must be discarded and regenerated into a fresh directory.

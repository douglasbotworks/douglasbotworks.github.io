import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import os
import struct
import subprocess
import warnings
import stat
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from deliver_repair import deliver
from handoff_archive import pack, verify

class HandoffArchiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Worker denies directory removal; retain ignored test fixtures.
        cls.root = Path(tempfile.mkdtemp(prefix='tmp-repair-handoff-', dir=ROOT))
        cls.delivery = cls.root / 'delivery'
        deliver(ROOT / 'contracts/order-total.json', ROOT / 'before/order-total.js',
                ROOT / 'order-total.js', cls.delivery)
        cls.archive = cls.root / 'valid.zip'
        cls.result = pack(cls.delivery, cls.archive)

    def test_real_handoff_roundtrip_and_exclusive_output(self):
        result = verify(self.archive, self.result['sha256'])
        self.assertTrue(result['contentConsistent'])
        self.assertFalse(result['executionPerformed'])
        self.assertEqual(result['members'], 10)
        with self.assertRaises(FileExistsError):
            pack(self.delivery, self.archive)
        self.assertEqual(hashlib.sha256(self.archive.read_bytes()).hexdigest(), self.result['sha256'])

    def test_extra_source_and_changed_bytes_refuse_pack(self):
        extra = self.delivery / 'private.txt'
        extra.write_text('not for delivery')
        try:
            with self.assertRaisesRegex(ValueError, 'inventory'):
                pack(self.delivery, self.root / 'extra.zip')
            self.assertFalse((self.root / 'extra.zip').exists())
        finally:
            extra.unlink()
        module = self.delivery / 'after/module.mjs'
        previous = module.read_bytes()
        try:
            module.write_bytes(previous + b'\n')
            with self.assertRaisesRegex(ValueError, 'content mismatch'):
                pack(self.delivery, self.root / 'changed.zip')
            self.assertFalse((self.root / 'changed.zip').exists())
        finally:
            module.write_bytes(previous)

    def test_export_permissions_and_existing_symlink_refusal(self):
        for mask in (0o022, 0o077, 0):
            with self.subTest(umask=mask):
                output = self.root / f'private-{mask:o}.zip'
                previous = os.umask(mask)
                try:
                    result = pack(self.delivery, output)
                finally:
                    os.umask(previous)
                self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o600)
                self.assertEqual(result['sha256'], self.result['sha256'])
                self.assertTrue(verify(output, result['sha256'])['contentConsistent'])
        target = self.root / 'existing-private.txt'
        target.write_bytes(b'preserve existing bytes')
        target.chmod(0o640)
        link = self.root / 'existing-link.zip'
        link.symlink_to(target)
        with self.assertRaises(FileExistsError):
            pack(self.delivery, link)
        self.assertEqual(target.read_bytes(), b'preserve existing bytes')
        self.assertEqual(stat.S_IMODE(target.stat().st_mode), 0o640)

    def test_symlink_refused(self):
        module = self.delivery / 'after/module.mjs'
        saved = self.root / 'saved.mjs'
        module.rename(saved)
        try:
            module.symlink_to(saved)
            with self.assertRaises(OSError):
                pack(self.delivery, self.root / 'symlink.zip')
        finally:
            module.unlink()
            saved.rename(module)

    def modified_zip(self, name, replacement, duplicate=False, compression=zipfile.ZIP_STORED):
        buffer = io.BytesIO()
        with zipfile.ZipFile(self.archive) as source, zipfile.ZipFile(buffer, 'w', compression=compression) as target:
            for entry in source.infolist():
                target.writestr(entry.filename, replacement if entry.filename == name else source.read(entry))
            if duplicate:
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore', UserWarning)
                    target.writestr(name, replacement)
        path = self.root / 'modified.zip'
        path.write_bytes(buffer.getvalue())
        return path, hashlib.sha256(buffer.getvalue()).hexdigest()

    def test_archive_digest_and_member_tampering(self):
        with self.assertRaisesRegex(ValueError, 'SHA256 mismatch'):
            verify(self.archive, '0' * 64)
        path, digest = self.modified_zip('after/module.mjs', b'changed')
        with self.assertRaisesRegex(ValueError, 'content mismatch'):
            verify(path, digest)

    def test_duplicate_and_compressed_members_refused(self):
        path, digest = self.modified_zip('DELIVERY.md', b'changed', duplicate=True)
        with self.assertRaisesRegex(ValueError, 'inventory'):
            verify(path, digest)
        path, digest = self.modified_zip('DELIVERY.md', b'changed', compression=zipfile.ZIP_DEFLATED)
        with self.assertRaisesRegex(ValueError, 'Unsupported'):
            verify(path, digest)

    def test_member_metadata_refuses_special_files_and_dos_directories(self):
        # Contents, inventory and digest all match: metadata alone must refuse.
        for creator in (0, 3):
            for mode, dos, accepted in [
                (stat.S_IFREG | 0o644, 0, True), (0o600, 0, True),
                (stat.S_IFREG | 0o644, 0x10, False), (0o600, 0x10, False),
                (stat.S_IFDIR | 0o755, 0, False),
                (stat.S_IFLNK | 0o777, 0, False),
                (stat.S_IFIFO | 0o600, 0, False),
                (stat.S_IFSOCK | 0o600, 0, False),
                (stat.S_IFCHR | 0o600, 0, False),
                (stat.S_IFBLK | 0o600, 0, False),
            ]:
                with self.subTest(creator=creator, mode=mode, dos=dos):
                    buffer = io.BytesIO()
                    with zipfile.ZipFile(self.archive) as source, zipfile.ZipFile(buffer, 'w') as target:
                        for entry in source.infolist():
                            if entry.filename == 'DELIVERY.md':
                                entry.create_system = creator
                                entry.external_attr = (mode << 16) | dos
                            target.writestr(entry, source.read(entry))
                    path = self.root / 'metadata.zip'
                    path.write_bytes(buffer.getvalue())
                    digest = hashlib.sha256(buffer.getvalue()).hexdigest()
                    if accepted:
                        self.assertTrue(verify(path, digest)['contentConsistent'])
                    else:
                        with self.assertRaisesRegex(ValueError, 'Unsupported'):
                            verify(path, digest)
        result = subprocess.run([sys.executable, str(ROOT / 'handoff_archive.py'),
                                 'verify', str(path), digest], capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, '')
        self.assertNotIn('Traceback', result.stderr)
        self.assertIn('Unsupported', result.stderr)

    def test_manifest_duplicate_keys_and_boolean_version_refused(self):
        for data, message in [(b'{"version":1,"version":1}', 'Duplicate'),
                              (json.dumps({'version': True, 'fixtureVerified': True, 'files': {}}).encode(), 'Invalid')]:
            path, digest = self.modified_zip('MANIFEST.json', data)
            with self.assertRaisesRegex(ValueError, message):
                verify(path, digest)

    def test_corrupt_crc_cli_refuses_without_traceback(self):
        raw = bytearray(self.archive.read_bytes())
        with zipfile.ZipFile(self.archive) as archive:
            offset = archive.getinfo('after/module.mjs').header_offset
        name_len, extra_len = struct.unpack_from('<HH', raw, offset + 26)
        raw[offset + 30 + name_len + extra_len] ^= 1
        damaged = self.root / 'damaged.zip'
        damaged.write_bytes(raw)
        result = subprocess.run([sys.executable, str(ROOT / 'handoff_archive.py'),
                                 'verify', str(damaged), hashlib.sha256(raw).hexdigest()],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn('CRC', result.stderr)
        self.assertNotIn('Traceback', result.stderr)
        self.assertEqual(result.stdout, '')

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO unavailable')
    def test_fifo_archive_fails_promptly(self):
        fifo = self.root / 'archive.fifo'
        os.mkfifo(fifo)
        result = subprocess.run([sys.executable, str(ROOT / 'handoff_archive.py'),
                                 'verify', str(fifo), '0' * 64], capture_output=True,
                                text=True, timeout=3)
        self.assertEqual(result.returncode, 1)
        self.assertIn('regular file', result.stderr)
        self.assertEqual(result.stdout, '')

if __name__ == '__main__':
    unittest.main()

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from release_repair import release
from handoff_archive import pack as real_pack


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        # Retain private fixtures under the repository's existing tmp* ignore
        # policy, matching the other delivery tests in the managed worker.
        self.temp = Path(tempfile.mkdtemp(prefix='tmp-release-', dir=ROOT))
        self.out = self.temp / 'release'
        self.contract = ROOT / 'contracts/order-total.json'
        self.pin = hashlib.sha256(self.contract.read_bytes()).hexdigest()
        self.before = ROOT / 'before/order-total.js'
        self.after = ROOT / 'order-total.js'

    def test_archive_recipient_rerun_and_existing_output_refusal(self):
        receipt = release(self.contract, self.before, self.after, self.out, self.pin)
        self.assertFalse(receipt['customerAccepted'])
        self.assertEqual(receipt, json.loads((self.out / 'RECEIPT.json').read_text()))
        recipient = self.temp / 'recipient'
        with zipfile.ZipFile(self.out / 'handoff.zip') as archive:
            archive.extractall(recipient)
        run = subprocess.run(['node', 'contract-review.js', '--contract-sha256', self.pin,
                              'contract.json', 'before/module.mjs', 'after/module.mjs'],
                             cwd=recipient, capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertEqual(json.loads(run.stdout), json.loads((recipient / 'report.json').read_text()))
        saved = (self.out / 'RECEIPT.json').read_bytes()
        with self.assertRaises(FileExistsError):
            release(self.contract, self.before, self.after, self.out, self.pin)
        self.assertEqual(saved, (self.out / 'RECEIPT.json').read_bytes())

    def test_wrong_pin_never_reads_modules_or_marks_complete(self):
        with self.assertRaisesRegex(ValueError, 'SHA256 mismatch'):
            release(self.contract, '/missing-before', '/missing-after', self.out, '0' * 64)
        self.assertEqual(list(self.out.iterdir()), [])

    def test_failed_repair_never_marks_complete(self):
        with self.assertRaisesRegex(ValueError, 'Repair not verified'):
            release(self.contract, self.before, self.before, self.out, self.pin)
        self.assertFalse((self.out / 'RECEIPT.json').exists())
        self.assertFalse((self.out / 'handoff.zip').exists())

    def test_archive_corruption_refuses_completion(self):
        def corrupted(root, output):
            result = real_pack(root, output)
            with Path(output).open('ab') as destination:
                destination.write(b'changed')
            return result
        with patch('release_repair.pack', corrupted):
            with self.assertRaisesRegex(ValueError, 'Archive SHA256 mismatch'):
                release(self.contract, self.before, self.after, self.out, self.pin)
        self.assertFalse((self.out / 'RECEIPT.json').exists())


if __name__ == '__main__':
    unittest.main()

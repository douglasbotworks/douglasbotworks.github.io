# Synthetic asynchronous state repair

Independent fictional example, not a client result or a diagnosis of any job.
Two searches overlap: request 2 finishes before request 1. The faulty function
shows request 1's stale result. The repaired function accepts completions only
for the active loading request, and ignores completions after cancel or settlement.

`requestTrace(events)` simulates ordered callbacks as plain JSON events. It makes
no network requests and does not run React, render a UI, abort fetch, or test browser
behavior. Increasing positive safe-integer IDs must be allocated by the caller
within one stream; a mounted component needs its own lifecycle cleanup. New starts
clear visible data/errors. A terminal event wins once; duplicate completions are
ignored. Invalid events throw rather than silently corrupting state. These choices
must be agreed with a real client before integration.

From repository root:

```sh
node contract-review.js --inspect samples/request-state/contract.json
node contract-review.js samples/request-state/contract.json samples/request-state/before.js samples/request-state/after.js
```

Use the inspection SHA256 with `--contract-sha256 HASH` to pin execution or the
existing `deliver_repair.py` command. The same fixture runs against both versions.
The fixture covers ordering, stale errors, cancellation, duplicate completion,
older starts, normal success/error and empty input. Separate Node tests cover
nonmutation and malformed events. The handoff's runner remains a trusted-code
executor, not a sandbox or proof of actual customer acceptance.

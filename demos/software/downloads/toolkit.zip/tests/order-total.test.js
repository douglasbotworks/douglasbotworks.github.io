import { test } from 'node:test';
import assert from 'node:assert/strict';
import { orderTotal } from '../order-total.js';

test('form strings sum correctly across multiple lines and shipping', () => {
  assert.equal(orderTotal([
    { unitPrice: '12.50', quantity: 2, shipping: '3.00' },
    { unitPrice: '4.99', quantity: 1, shipping: '0.00' }
  ]), '32.99');
});
test('fractional amounts remain exact and empty orders return zero', () => {
  assert.equal(orderTotal([{ unitPrice: '0.10', quantity: 3, shipping: '0.20' }]), '0.50');
  assert.equal(orderTotal([]), '0.00');
});
test('invalid precision and malformed amounts are rejected', () => {
  for (const value of ['1.001', '-1', 'NaN', '', ' 1', '1e3', 1, null]) {
    assert.throws(() => orderTotal([{ unitPrice: value, quantity: 1, shipping: '0' }]), TypeError);
  }
});
test('invalid quantities and unsafe totals are rejected', () => {
  for (const quantity of [0, -1, 1.5, '2', Infinity]) {
    assert.throws(() => orderTotal([{ unitPrice: '1', quantity, shipping: '0' }]), TypeError);
  }
  assert.throws(() => orderTotal([{ unitPrice: '90071992547409.92', quantity: 1, shipping: '0' }]), RangeError);
  assert.throws(() => orderTotal([{ unitPrice: '10000000000000', quantity: 10, shipping: '0' }]), RangeError);
});

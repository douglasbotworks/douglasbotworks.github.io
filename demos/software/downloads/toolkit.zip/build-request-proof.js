// Public fictional evidence only. The trusted source runner executes at build time.
import {reviewContract} from './contract-review.js';
import {readFileSync, mkdirSync, existsSync, writeFileSync} from 'node:fs';
import {resolve, join} from 'node:path';
import {fileURLToPath} from 'node:url';

const [destination, ...extra] = process.argv.slice(2);
if (!destination || extra.length || existsSync(resolve(destination))) {
  console.error('Usage: node build-request-proof.js NEW_OUTPUT_DIRECTORY');
  process.exit(1);
}
const root = fileURLToPath(new URL('.', import.meta.url));
const sample = join(root, 'samples/request-state');
const report = await reviewContract(join(sample, 'contract.json'), join(sample, 'before.js'), join(sample, 'after.js'));
if (!report.verified) throw new Error('Request-state example must demonstrate a verified repair');
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const [before, after] = report.implementations;
const rows = before.cases.map((c, i) => `<tr><th scope="row">${escape(c.name)}</th><td><code>${escape(JSON.stringify(c.expected.value))}</code></td><td><code>${escape(JSON.stringify(c.actual.value))}</code><strong class="${c.status}">${c.status.toUpperCase()}</strong></td><td><code>${escape(JSON.stringify(after.cases[i].actual.value))}</code><strong class="${after.cases[i].status}">${after.cases[i].status.toUpperCase()}</strong></td></tr>`).join('');
const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Keep the newer result — Douglas Bot Works</title><style>
*{box-sizing:border-box}body{margin:0;background:#f5f5ef;color:#202a35;font:17px/1.65 system-ui,sans-serif}main{max-width:1080px;margin:auto;padding:32px 22px}h1{font-size:clamp(32px,6vw,56px);line-height:1.15}p{max-width:780px}a{color:#285784}a:focus-visible{outline:3px solid #9d450c;outline-offset:4px}.table-wrap{overflow-x:auto;background:white;border:1px solid #ccd2d6}table{width:100%;border-collapse:collapse;text-align:left;font-size:14px}th,td{padding:14px;border-bottom:1px solid #ccd2d6;vertical-align:top}code{font:13px/1.5 ui-monospace,monospace;overflow-wrap:anywhere}strong{display:block}.failed{color:#a03c12}.passed{color:#23643e}.label{font-size:13px;font-weight:bold}section{margin-top:38px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#e9edf0;padding:18px}
</style></head><body><main><a href="../index.html">Back to the order-total example</a>
<p class="label">SYNTHETIC DEMONSTRATION · NOT CLIENT WORK</p><h1>Keep the newer result.</h1>
<p>Two searches overlap. Request 2 finishes first, then request 1 returns an older result. The faulty state function replaces the newer result with the older one. The repair accepts completions only for the active loading request.</p>
<p>The same ${report.summary.caseCount} fictional callback traces run against both functions: ${report.summary.beforeFailures} original failures and ${report.summary.afterPasses} repaired passes. Normal success, error and empty traces also check behavior that should stay consistent.</p>
<div class="table-wrap"><table><caption>Actual final JSON states from the shared fixture</caption><thead><tr><th scope="col">Case</th><th scope="col">Expected</th><th scope="col">Original</th><th scope="col">Repaired</th></tr></thead><tbody>${rows}</tbody></table></div>
<section><h2>Inspect the evidence</h2><p><a href="report.json" download>Download the complete results</a> · <a href="contract.json" download>Download the shared fixture</a></p>
<p>The report records expected and actual values, entry-module hashes and the fixture hash. Hashes establish byte consistency with a trusted copy; they do not authenticate a seller or prove client acceptance.</p>
<h2>Reproduce from the trusted source package</h2><pre><code>node contract-review.js --contract-sha256 ${report.contractSha256}
  samples/request-state/contract.json
  samples/request-state/before.js
  samples/request-state/after.js</code></pre><p>Enter the command on one line from the source repository root. Node.js 22+. A verified repair returns exit 0. The source package is supplied separately; this marketing page executes no code.</p></section>
<section><h2>Agree on integration before a real repair</h2><p>This example simulates callback order as plain JSON. It does not fetch data, render React, abort network requests or test a browser. Callers must allocate increasing positive safe-integer request IDs within one stream and handle component lifecycle cleanup. New starts clear data and errors; terminal events settle once. Those choices need explicit acceptance for a real application.</p>
<p>No production fix, customer history, native browser acceptance or earned revenue is claimed. The proposed USD 150 repair pilot requires an approved client, authorized source, a reproducible defect, agreed scope and payment terms.</p></section></main></body></html>`;
const output = resolve(destination);
mkdirSync(output, {recursive:true});
writeFileSync(join(output, 'index.html'), html);
writeFileSync(join(output, 'report.json'), JSON.stringify({synthetic:true, ...report}, null, 2) + '\n');
writeFileSync(join(output, 'contract.json'), readFileSync(join(sample, 'contract.json')));
console.log(JSON.stringify({output, files:3, ...report.summary}));

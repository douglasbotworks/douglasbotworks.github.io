// Synthetic defect: form inputs are strings, so + concatenates amounts.
export function orderTotal(lines) {
  return lines.reduce((total, line) => total + line.unitPrice * line.quantity + line.shipping, 0);
}

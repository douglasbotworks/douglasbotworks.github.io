// Synthetic pure-state example. IDs increase within one mounted request stream.
export function requestTrace(events) {
  if (!Array.isArray(events)) throw new TypeError('Events must be an array');
  let state = {requestId: 0, status: 'idle', data: null, error: null};
  for (const event of events) {
    if (!event || !['start', 'success', 'failure', 'cancel'].includes(event.type) ||
        !Number.isSafeInteger(event.id) || event.id < 1 ||
        (event.type === 'success' && !Object.hasOwn(event, 'data')) ||
        (event.type === 'failure' && typeof event.error !== 'string')) {
      throw new TypeError('Invalid request event');
    }
    if (event.type === 'start') {
      if (event.id > state.requestId) {
        state = {requestId: event.id, status: 'loading', data: null, error: null};
      }
      continue;
    }
    // A canceled/completed request cannot be revived by a later completion.
    if (event.id !== state.requestId || state.status !== 'loading') continue;
    if (event.type === 'success') state = {...state, status: 'success', data: event.data};
    if (event.type === 'failure') state = {...state, status: 'error', error: event.error};
    if (event.type === 'cancel') state = {...state, status: 'idle'};
  }
  return state;
}

"""Verify a delivered release ZIP against its report without extracting files."""
import argparse
import hashlib
import re
import stat
import struct
import zipfile
import zlib
from pathlib import Path
from release_check import MAX_FILE, MAX_TOTAL, HARD_MAX_FILES, member_name, read_regular, strict_json


def check_deflate_stream(stream, item, size):
    """Check raw stream completion: ZipExtFile stops at the declared size.

    Called after ZipFile.open has validated the local header/name/overlap.
    Read only the central directory's compressed extent, with bounded output.
    """
    stream.seek(item.header_offset)
    header = stream.read(30)
    if len(header) != 30 or header[:4] != b'PK\x03\x04':
        raise ValueError('Invalid compressed member: ' + item.filename)
    name_length, extra_length = struct.unpack_from('<HH', header, 26)
    stream.seek(name_length + extra_length, 1)
    remaining, decoded = item.compress_size, 0
    decoder = zlib.decompressobj(-zlib.MAX_WBITS)
    while remaining:
        block = stream.read(min(65536, remaining))
        if not block:
            raise ValueError('Invalid compressed member: ' + item.filename)
        remaining -= len(block)
        while block:
            output = decoder.decompress(block, min(65536, size - decoded + 1))
            decoded += len(output)
            if decoded > size:
                raise ValueError('Member exceeds reported size: ' + item.filename)
            if decoder.unused_data or (decoder.eof and remaining):
                raise ValueError('Trailing compressed member data: ' + item.filename)
            block = decoder.unconsumed_tail
    if not decoder.eof or decoded != size:
        raise ValueError('Incomplete compressed member: ' + item.filename)


def verify(report_path, archive_path):
    report = strict_json(read_regular(Path(report_path)).decode('utf-8'))
    if (not isinstance(report, dict) or type(report.get('schema_version')) is not int
            or report['schema_version'] != 1):
        raise ValueError('Unsupported report schema')
    files = report.get('files')
    if not isinstance(files, list) or not 1 <= len(files) <= HARD_MAX_FILES:
        raise ValueError('Invalid report inventory')
    expected = {}
    for item in files:
        if not isinstance(item, dict):
            raise ValueError('Invalid inventory entry')
        name, size, digest = item.get('path'), item.get('bytes'), item.get('sha256')
        if (not member_name(name) or name in expected or type(size) is not int
                or not 0 <= size <= MAX_FILE or not isinstance(digest, str)
                or not re.fullmatch('[0-9a-f]{64}', digest)):
            raise ValueError('Invalid or duplicate inventory entry')
        expected[name] = (size, digest)
    total = sum(size for size, _ in expected.values())
    if total > MAX_TOTAL or type(report.get('total_bytes')) is not int or report['total_bytes'] != total:
        raise ValueError('Invalid report total')
    digest = report.get('archive_sha256')
    if not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest):
        raise ValueError('Report must contain a valid archive SHA256')
    # Open once, reject symlinks/nonregular input, hash bounded compressed bytes,
    # then inspect the same descriptor. Never extract or execute archive members.
    import os
    fd = os.open(str(archive_path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_TOTAL + 16 * 1024 * 1024:
            raise ValueError('Unsupported archive input or size')
        hasher = hashlib.sha256()
        consumed = 0
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            consumed += len(block)
            if consumed > MAX_TOTAL + 16 * 1024 * 1024:
                raise ValueError('Archive grew beyond size limit')
            hasher.update(block)
        if hasher.hexdigest() != digest:
            raise ValueError('Archive SHA256 does not match report')
        stream.seek(0)
        with zipfile.ZipFile(stream) as archive:
            members = archive.infolist()
            # ZipInfo.filename can differ from the stored name after NUL truncation.
            # Reject it before comparing the apparent inventory to the report.
            if any(m.orig_filename != m.filename or not member_name(m.orig_filename) for m in members):
                raise ValueError('Unsupported or altered archive member name')
            names = [m.filename for m in members]
            if len(names) != len(set(names)) or set(names) != set(expected):
                raise ValueError('Archive members do not match report inventory')
            for item in members:
                size, wanted = expected[item.filename]
                kind = stat.S_IFMT(item.external_attr >> 16)
                if (item.is_dir() or item.external_attr & 0x10 or kind not in {0, stat.S_IFREG}
                        or item.flag_bits & 1 or item.file_size != size):
                    raise ValueError('Unsupported member or size mismatch: ' + item.filename)
                if item.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
                    raise ValueError('Unsupported member compression: ' + item.filename)
                if item.compress_type == zipfile.ZIP_STORED and item.compress_size != size:
                    raise ValueError('Stored member size mismatch: ' + item.filename)
                hasher = hashlib.sha256()
                consumed = 0
                try:
                    with archive.open(item) as member:
                        while True:
                            block = member.read(min(1024 * 1024, size - consumed + 1))
                            if not block:
                                break
                            consumed += len(block)
                            if consumed > size:
                                raise ValueError('Member exceeds reported size: ' + item.filename)
                            hasher.update(block)
                    if item.compress_type == zipfile.ZIP_DEFLATED:
                        check_deflate_stream(stream, item, size)
                except (zlib.error, EOFError) as exc:
                    raise ValueError('Invalid compressed member: ' + item.filename) from exc
                if consumed != size or hasher.hexdigest() != wanted:
                    raise ValueError('Member SHA256 does not match report: ' + item.filename)
    return len(expected), total


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report')
    parser.add_argument('archive')
    args = parser.parse_args(argv)
    try:
        count, total = verify(args.report, args.archive)
        print('Verified {} files; {} bytes; archive and member hashes match report.'.format(count, total))
        return 0
    except (OSError, ValueError, KeyError, RuntimeError, zipfile.BadZipFile, NotImplementedError) as exc:
        print('Delivery verification failed: ' + str(exc))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { reviewContract, validateContract, parseContractJSON, inspectContract } from '../contract-review.js';

const root = fileURLToPath(new URL('../', import.meta.url));
const sample = join(root, 'contracts/order-total.json');
test('sample defect is reproduced with unchanged contract and exact return types', async () => {
  const report = await reviewContract(sample, join(root, 'before/order-total.js'), join(root, 'order-total.js'));
  assert.equal(report.verified, true);
  assert.equal(report.implementations[0].cases[2].actual.type, 'number');
  assert.equal(report.implementations[1].cases[2].actual.type, 'string');
  assert.equal(report.implementations[0].cases.filter(c => c.status === 'failed').length, 3);
  assert.equal(report.implementations[1].cases.filter(c => c.status === 'passed').length, 3);
  assert.match(report.contractSha256, /^[a-f0-9]{64}$/);
});

async function fixture(t, before, after, cases, timeoutMs = 2000) {
  const dir = await mkdtemp(join(tmpdir(), 'contract-review-'));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const contract = join(dir, 'contract.json');
  const old = join(dir, 'before.mjs'), next = join(dir, 'after.mjs');
  await Promise.all([
    writeFile(contract, JSON.stringify({ version: 1, exportName: 'repair', timeoutMs, cases })),
    writeFile(old, before), writeFile(next, after),
  ]);
  return { paths: [contract, old, next], run: () => reviewContract(contract, old, next) };
}
const valueCase = { name: 'one', args: [2], expected: { value: 4 } };
test('raw contracts reject duplicate keys before reading or executing modules', async t => {
  const f = await fixture(t, 'throw new Error("must not execute");', 'throw new Error("must not execute");', [valueCase]);
  for (const text of [
    '{"version":1,"version":1,"exportName":"repair","timeoutMs":2000,"cases":[]}',
    '{"value":{"total":4,"total":5}}',
    '{"args":[{"name":1,"na\\u006de":2}]}',
    '{"__proto__":{},"__proto__":{}}',
  ]) {
    await writeFile(f.paths[0], text);
    await assert.rejects(f.run(), /Duplicate contract object key/);
  }
  await writeFile(f.paths[0], '{"version":1,"version":1}');
  const cli = spawnSync(process.execPath, [join(root, 'contract-review.js'), f.paths[0], 'missing-before.mjs', 'missing-after.mjs'], {encoding:'utf8'});
  assert.equal(cli.status, 1);
  assert.equal(cli.stdout, '');
  assert.match(cli.stderr, /Duplicate contract object key/);
});
test('contract token inspection preserves string data and sibling keys, bounds nesting and numbers', () => {
  const input = {a:[{x:'quotes " braces { commas , colon : and slash \\'},{x:2}], b:{x:3}, n:-1.25e-4};
  assert.deepEqual(parseContractJSON(JSON.stringify(input)), input);
  assert.throws(() => parseContractJSON('{"n":1e400}'), /Nonfinite/);
  assert.throws(() => parseContractJSON('['.repeat(32)+'0'+']'.repeat(32)), /nesting/);
  assert.throws(() => parseContractJSON('{"a":1,}'), SyntaxError);
  assert.equal(parseContractJSON('null'), null);
});
test('async repairs, object outputs and expected exceptions are supported', async t => {
  const f = await fixture(t, 'export const repair = () => null;',
    'export async function repair(x) {if(x === null) throw new TypeError("bad input"); return {answer:x*2};}',
    [{ ...valueCase, expected: { value: { answer: 4 } } },
     { name: 'rejection', args: [null], expected: { error: { name: 'TypeError', message: 'bad input' } } }]);
  assert.equal((await f.run()).verified, true);
});
test('already passing original cannot establish a reproduced repair', async t => {
  const f = await fixture(t, 'export const repair = x => x*2;', 'export const repair = x => x*2;', [valueCase]);
  assert.equal((await f.run()).verified, false);
});
test('one remaining repaired failure prevents verified delivery', async t => {
  const f = await fixture(t, 'export const repair = () => 0;', 'export const repair = x => x*2;',
    [valueCase, { name: 'another', args: [3], expected: { value: 7 } }]);
  assert.equal((await f.run()).verified, false);
});
test('a synchronous infinite loop times out and does not block subsequent cases', async t => {
  const f = await fixture(t, 'export function repair(x) {if(x===2) while(true){} return 4;}',
    'export const repair = () => 4;', [valueCase, { ...valueCase, name: 'next', args: [3] }], 500);
  const r = await f.run();
  assert.equal(r.verified, false);
  assert.equal(r.implementations[0].cases[0].diagnostic, 'Case timed out');
  assert.equal(r.implementations[0].cases[1].status, 'passed');
});
test('import failure is not an expected function exception', async t => {
  const f = await fixture(t, 'throw new Error("bad input");', 'export function repair(){throw new Error("bad input");}',
    [{ name: 'error', args: [], expected: { error: { name: 'Error', message: 'bad input' } } }]);
  const r = await f.run();
  assert.equal(r.verified, false);
  assert.equal(r.implementations[0].cases[0].status, 'execution-error');
  assert.equal(r.implementations[1].cases[0].status, 'passed');
});
test('undefined, nonfinite and cyclic return values fail closed', async t => {
  for (const expression of ['undefined', 'Infinity', 'new Date()', 'Array(2)',
    '(()=>{const v={};v.self=v;return v;})()']) {
    const f = await fixture(t, 'export const repair = () => 0;', `export const repair = () => ${expression};`, [valueCase]);
    const r = await f.run();
    assert.equal(r.verified, false);
    assert.equal(r.implementations[1].cases[0].status, 'execution-error');
  }
});
test('worker termination prevents verification and missing export is an execution error', async t => {
  for (const body of ['process.exit(0);', 'export const other = () => 4;']) {
    const f = await fixture(t, 'export const repair = () => 0;', body, [valueCase]);
    const r = await f.run();
    assert.equal(r.verified, false);
    assert.equal(r.implementations[1].cases[0].status, 'execution-error');
  }
});
test('changed entry module invalidates the entire review', async t => {
  const f = await fixture(t, 'export const repair = () => 0;', 'export const repair = () => 4;', [valueCase]);
  await writeFile(f.paths[1], `import {writeFileSync} from 'node:fs'; export function repair(){writeFileSync(${JSON.stringify(f.paths[2])}, 'export const repair=()=>4; // changed');return 0;}`);
  await assert.rejects(f.run, /changed during review/);
});
test('fresh workers reset module state and console output cannot corrupt CLI report', async t => {
  const f = await fixture(t, 'export const repair = () => 0;',
    'console.log("debug noise"); console.error("more noise"); let count=0;export const repair = () => ++count;',
    [{ name: 'first', args: [], expected: { value: 1 } }, { name: 'second', args: [], expected: { value: 1 } }]);
  const r = spawnSync(process.execPath, ['contract-review.js', ...f.paths], { cwd: root, encoding: 'utf8', timeout: 15000 });
  assert.equal(r.status, 0); assert.equal(r.stderr, '');
  assert.equal(JSON.parse(r.stdout).verified, true);
  assert.doesNotMatch(r.stdout, /debug noise|more noise/);
});
test('malformed or ambiguous contract shape is rejected before module execution', () => {
  const base = { version: 1, exportName: 'repair', timeoutMs: 2000, cases: [valueCase] };
  for (const invalid of [{ ...base, cases: [] }, { ...base, timeoutMs: 0 }, { ...base, exportName: true },
    { ...base, cases: [valueCase, valueCase] }, { ...base, extra: true },
    { ...base, cases: [{ ...valueCase, expected: { value: 4, error: { name: 'Error', message: '' } } }] }]) {
    assert.throws(() => validateContract(invalid), /Invalid/);
  }
});
test('CLI distinguishes unverified comparisons from input failures', () => {
  const unverified = spawnSync(process.execPath, ['contract-review.js', sample, 'order-total.js', 'order-total.js'], { cwd: root, encoding: 'utf8' });
  assert.equal(unverified.status, 2); assert.equal(JSON.parse(unverified.stdout).verified, false);
  const invalid = spawnSync(process.execPath, ['contract-review.js'], { cwd: root, encoding: 'utf8' });
  assert.equal(invalid.status, 1); assert.match(invalid.stderr, /Usage:/); assert.equal(invalid.stdout, '');
});


test('malformed UTF-8 is rejected without replacing agreed contract text', async t => {
  const f = await fixture(t, 'export const repair = () => 0;', 'export const repair = () => 4;', [valueCase]);
  const prefix = Buffer.from('{"version":1,"exportName":"repair","timeoutMs":2000,"cases":[{"name":"');
  const suffix = Buffer.from('","args":[2],"expected":{"value":4}}]}');
  await writeFile(f.paths[0], Buffer.concat([prefix, Buffer.from([0xff]), suffix]));
  await assert.rejects(f.run, /encoded data|encoding/i);
});

test('oversized inputs fail before workers start', async t => {
  const f = await fixture(t, 'export const repair = () => 0;', 'export const repair = () => 4;', [valueCase]);
  await writeFile(f.paths[1], Buffer.alloc(524289));
  await assert.rejects(f.run, /size limit/);
});


test('oversized exceptions cannot pass by matching a truncated prefix', async t => {
  for (const field of ['name', 'message']) {
    const limit = field === 'name' ? 200 : 2000;
    const expected = { name: 'Error', message: 'boom', [field]: 'x'.repeat(limit) };
    const f = await fixture(t, 'export const repair = () => 0;',
      `export function repair(){const e=new Error("boom");e.${field}="x".repeat(${limit + 1});throw e;}`,
      [{name:'exception',args:[],expected:{error:expected}}]);
    const r = await f.run();
    assert.equal(r.verified, false);
    assert.equal(r.implementations[1].cases[0].status, 'execution-error');
    assert.match(r.implementations[1].cases[0].diagnostic, /exception exceeds/);
  }
});
test('expected exception limits are checked before implementation file access', async t => {
  const f = await fixture(t, '', '', [valueCase]);
  for (const field of ['name','message']) {
    const error = {name:'Error',message:'boom',[field]:'x'.repeat(field === 'name' ? 201 : 2001)};
    await writeFile(f.paths[0], JSON.stringify({version:1,exportName:'repair',timeoutMs:2000,cases:[{name:'error',args:[],expected:{error}}]}));
    await assert.rejects(reviewContract(f.paths[0], 'missing-before.mjs', 'missing-after.mjs'), /Invalid case/);
  }
});
test('return bound measures UTF-8 bytes and accepts the exact byte boundary', async t => {
  for (const [count, status] of [[10922, 'passed'], [10923, 'execution-error']]) {
    const f = await fixture(t, 'export const repair=()=>0;',
      `export const repair=()=>"€".repeat(${count});`,
      [{name:'unicode',args:[],expected:{value:'€'.repeat(10922)}}]);
    const r = await f.run();
    assert.equal(r.implementations[1].cases[0].status,status);
    assert.equal(r.verified,status === 'passed');
  }
});

test('exact maximum exception strings remain supported without truncation', async t => {
  const f = await fixture(t, 'export const repair=()=>0;',
    'export function repair(){const e=new Error("x".repeat(2000));e.name="n".repeat(200);throw e;}',
    [{name:'maximum',args:[],expected:{error:{name:'n'.repeat(200),message:'x'.repeat(2000)}}}]);
  const r = await f.run();
  assert.equal(r.verified,true);
  assert.deepEqual(r.implementations[1].cases[0].actual.error,{name:'n'.repeat(200),message:'x'.repeat(2000)});
});

test('contract inspection is non-executing and uses the exact review digest', () => {
  const inspected = spawnSync(process.execPath, ['contract-review.js','--inspect',sample], {cwd:root,encoding:'utf8'});
  assert.equal(inspected.status,0,inspected.stderr);
  const r = JSON.parse(inspected.stdout);
  assert.equal(r.executionPerformed,false);
  assert.equal(r.caseCount,3);
  assert.equal(r.caseNames.length,3);
  assert.equal(r.exportName,'orderTotal');
  assert.equal(Object.hasOwn(r,'verified'),false);
  const review = spawnSync(process.execPath,['contract-review.js',sample,'before/order-total.js','order-total.js'],{cwd:root,encoding:'utf8'});
  assert.equal(review.status,0,review.stderr);
  assert.equal(r.contractSha256,JSON.parse(review.stdout).contractSha256);
});
test('contract inspection refuses invalid and missing inputs with no report', async t => {
  const f = await fixture(t,'throw new Error("must not run");','throw new Error("must not run");',[valueCase]);
  await writeFile(f.paths[0],'{"version":1,"version":1}');
  for (const path of [f.paths[0],join(root,'missing-contract.json')]) {
    const cli = spawnSync(process.execPath,['contract-review.js','--inspect',path],{cwd:root,encoding:'utf8'});
    assert.equal(cli.status,1);
    assert.equal(cli.stdout,'');
    assert.notEqual(cli.stderr,'');
  }
});

 test('unrepresentable expected values fail inspection and review before module access', async t => {
  const f = await fixture(t, '', '', [valueCase]);
  const rawBase = value => `{"version":1,"exportName":"repair","timeoutMs":2000,"cases":[{"name":"value","args":[],"expected":{"value":${value}}}]}`;
  for (const value of ['-0', '{"nested":[-0]}', JSON.stringify('€'.repeat(10923))]) {
    await writeFile(f.paths[0], rawBase(value));
    await assert.rejects(reviewContract(f.paths[0], 'missing-before.mjs', 'missing-after.mjs'), /Invalid expected value/);
    const cli = spawnSync(process.execPath, [join(root,'contract-review.js'),'--inspect',f.paths[0]], {encoding:'utf8'});
    assert.equal(cli.status,1); assert.equal(cli.stdout,'');
    assert.match(cli.stderr,/Invalid expected value/);
  }
  const base = {version:1,exportName:'repair',timeoutMs:2000,cases:[valueCase]};
  for (const value of [undefined, NaN, new Date(), {answer:undefined}]) {
    assert.throws(() => validateContract({...base,cases:[{...valueCase,expected:{value}}]}), /Invalid expected value/);
  }
});

test('empty exception names are compared exactly rather than rewritten to Error', async t => {
  const body = 'export function repair(){const e=new Error("boom");e.name="";throw e;}';
  for (const [name, status] of [['', 'passed'], ['Error', 'failed']]) {
    const f = await fixture(t,'export const repair=()=>0;',body,
      [{name:'empty name',args:[],expected:{error:{name,message:'boom'}}}]);
    const report = await f.run();
    assert.equal(report.implementations[1].cases[0].actual.error.name,'');
    assert.equal(report.implementations[1].cases[0].status,status);
    assert.equal(report.verified,status === 'passed');
  }
});

test('pinned review accepts inspected bytes and refuses changed fixture before module reads', async t => {
  const f = await fixture(t, 'export const repair=()=>0;', 'export const repair=x=>x*2;', [valueCase]);
  const pin = (await inspectContract(f.paths[0])).contractSha256;
  assert.equal((await reviewContract(...f.paths, pin)).verified, true);
  const matched = spawnSync(process.execPath, [join(root, 'contract-review.js'), '--contract-sha256', pin, ...f.paths], {encoding:'utf8'});
  assert.equal(matched.status, 0, matched.stderr);
  assert.equal(JSON.parse(matched.stdout).contractSha256, pin);
  // Even whitespace changes require a new decision about the exact fixture bytes.
  const { readFile } = await import('node:fs/promises');
  await writeFile(f.paths[0], (await readFile(f.paths[0], 'utf8')) + '\n');
  for (const expected of [pin, 'A'.repeat(64), 'short', null]) {
    await assert.rejects(reviewContract(f.paths[0], 'absent-before.mjs', 'absent-after.mjs', expected), /SHA256/);
  }
  const refused = spawnSync(process.execPath, [join(root, 'contract-review.js'), '--contract-sha256', pin, f.paths[0], 'absent-before.mjs', 'absent-after.mjs'], {encoding:'utf8'});
  assert.equal(refused.status, 1);
  assert.equal(refused.stdout, '');
  assert.match(refused.stderr, /SHA256 mismatch/);
});

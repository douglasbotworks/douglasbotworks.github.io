import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from verify_demo import verify

class DeliveryTests(unittest.TestCase):
    def setUp(self):
        # Retain fixtures: this worker denies directory removal.
        self.temp = Path(tempfile.mkdtemp(prefix='delivery-test-', dir=ROOT))
        self.archive = self.temp / 'demo.zip'
        subprocess.run([sys.executable, str(ROOT / 'package_demo.py'), str(self.archive)], check=True, capture_output=True)

    def digest(self):
        return hashlib.sha256(self.archive.read_bytes()).hexdigest()

    def rewrite(self, mutate):
        with zipfile.ZipFile(self.archive) as source:
            contents = {name: source.read(name) for name in source.namelist()}
        mutate(contents)
        with zipfile.ZipFile(self.archive, 'w') as target:
            for name, data in contents.items():
                target.writestr(name, data)

    def test_clean_reproducible(self):
        self.assertTrue(verify(self.archive, self.digest())['verified'])
        other = self.temp / 'other.zip'
        subprocess.run([sys.executable, str(ROOT / 'package_demo.py'), str(other)], check=True, capture_output=True)
        self.assertEqual(self.archive.read_bytes(), other.read_bytes())

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO unavailable')
    def test_fifo_archive_refuses_promptly(self):
        fifo = self.temp / 'archive.fifo'
        os.mkfifo(fifo)
        run = subprocess.run([sys.executable, str(ROOT / 'verify_demo.py'), str(fifo), '0' * 64],
                             capture_output=True, text=True, timeout=3)
        self.assertEqual(run.returncode, 1)
        self.assertEqual(run.stdout, '')
        self.assertIn('regular file', run.stderr)

    def test_changed_source(self):
        self.rewrite(lambda contents: contents.__setitem__('order-total.js', b'changed'))
        with self.assertRaisesRegex(ValueError, 'Manifest content mismatch'):
            verify(self.archive, self.digest())

    def test_unexpected_member(self):
        self.rewrite(lambda contents: contents.__setitem__('../unexpected.js', b'bad'))
        with self.assertRaisesRegex(ValueError, 'inventory mismatch'):
            verify(self.archive, self.digest())

    def test_duplicate_manifest_key(self):
        self.rewrite(lambda contents: contents.__setitem__('MANIFEST.json', b'{"synthetic":true,"synthetic":true,"files":{}}'))
        with self.assertRaisesRegex(ValueError, 'Duplicate manifest key'):
            verify(self.archive, self.digest())

    def test_cli_stale_digest_and_corrupt_crc(self):
        command = [sys.executable, str(ROOT / 'verify_demo.py'), str(self.archive)]
        result = subprocess.run(command + ['0' * 64], capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn('SHA256 mismatch', result.stderr)
        with zipfile.ZipFile(self.archive) as source:
            offset = source.getinfo('order-total.js').header_offset
        raw = bytearray(self.archive.read_bytes())
        import struct
        name_len, extra_len = struct.unpack_from('<HH', raw, offset + 26)
        raw[offset + 30 + name_len + extra_len] ^= 1
        self.archive.write_bytes(raw)
        result = subprocess.run(command + [self.digest()], capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn('CRC', result.stderr)
        self.assertNotIn('Traceback', result.stderr)
        self.assertEqual(result.stdout, '')

if __name__ == '__main__':
    unittest.main()

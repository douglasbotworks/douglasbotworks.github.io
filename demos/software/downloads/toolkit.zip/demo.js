import assert from 'node:assert/strict';
import { orderTotal as before } from './before/order-total.js';
import { orderTotal as after } from './order-total.js';
const input = [
  { unitPrice: '12.50', quantity: 2, shipping: '3.00' },
  { unitPrice: '4.99', quantity: 1, shipping: '0.00' }
];
assert.notEqual(before(input), '32.99');
assert.equal(after(input), '32.99');
console.log(JSON.stringify({ synthetic: true, input, before: before(input), after: after(input), expected: '32.99' }, null, 2));

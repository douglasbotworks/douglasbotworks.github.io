import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from deliver_repair import deliver
from unittest.mock import patch
import deliver_repair

class RepairDeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = Path(tempfile.mkdtemp(prefix='tmp-repair-test-', dir=ROOT))
        self.contract = ROOT / 'contracts/order-total.json'
        self.before = ROOT / 'before/order-total.js'
        self.after = ROOT / 'order-total.js'
        self.output = self.temp / 'delivery'

    def test_recipient_rerun_hashes_and_actual_patch(self):
        result = deliver(self.contract, self.before, self.after, self.output)
        self.assertTrue(result['fixtureVerified'])
        manifest = json.loads((self.output / 'MANIFEST.json').read_text())
        actual_names = {p.relative_to(self.output).as_posix() for p in self.output.rglob('*') if p.is_file()}
        self.assertEqual(actual_names, set(manifest['files']) | {'MANIFEST.json'})
        for name, record in manifest['files'].items():
            data = (self.output / name).read_bytes()
            self.assertEqual(record, {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        command = [shutil.which('node'), 'contract-review.js', 'contract.json', 'before/module.mjs', 'after/module.mjs']
        run = subprocess.run(command, cwd=self.output, capture_output=True, text=True, env={})
        self.assertEqual(run.returncode, 0, run.stderr)
        report = json.loads(run.stdout)
        self.assertEqual(report, json.loads((self.output / 'report.json').read_text()))
        self.assertEqual(report['summary']['beforeFailures'], 3)
        self.assertEqual(report['summary']['afterPasses'], 3)
        patch_dir = self.temp / 'patch'
        patch_dir.mkdir()
        initialized = subprocess.run([shutil.which('git'), 'init', '--quiet'], cwd=patch_dir, capture_output=True, env={})
        self.assertEqual(initialized.returncode, 0, initialized.stderr)
        (patch_dir / 'module.mjs').write_bytes(self.before.read_bytes())
        applied = subprocess.run([shutil.which('git'), 'apply', '-p2', str(self.output / 'change.diff')],
                                 cwd=patch_dir, capture_output=True, env={})
        self.assertEqual(applied.returncode, 0, applied.stderr)
        self.assertEqual((patch_dir / 'module.mjs').read_bytes(), self.after.read_bytes())

    @unittest.skipUnless(os.name == 'posix', 'POSIX permissions required')
    def test_delivery_remains_private_under_permissive_umask(self):
        previous = os.umask(0)
        try:
            deliver(self.contract, self.before, self.after, self.output)
        finally:
            os.umask(previous)
        for path in [self.output, *self.output.rglob('*')]:
            self.assertEqual(path.stat().st_mode & 0o777,
                             0o700 if path.is_dir() else 0o600, str(path))

    def test_pinned_handoff_and_recipient_rerun(self):
        pin = hashlib.sha256(self.contract.read_bytes()).hexdigest()
        result = deliver(self.contract, self.before, self.after, self.output, pin)
        self.assertTrue(result['fixtureVerified'])
        self.assertIn('--contract-sha256 ' + pin, (self.output / 'DELIVERY.md').read_text())
        run = subprocess.run([shutil.which('node'), 'contract-review.js', '--contract-sha256', pin,
                              'contract.json', 'before/module.mjs', 'after/module.mjs'],
                             cwd=self.output, capture_output=True, text=True, env={})
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertEqual(json.loads(run.stdout), json.loads((self.output / 'report.json').read_text()))
        with (self.output / 'contract.json').open('ab') as changed:
            changed.write(b'\n')
        rerun = subprocess.run([shutil.which('node'), 'contract-review.js', '--contract-sha256', pin,
                                'contract.json', 'missing-before.mjs', 'missing-after.mjs'],
                               cwd=self.output, capture_output=True, text=True, env={})
        self.assertEqual(rerun.returncode, 1)
        self.assertEqual(rerun.stdout, '')
        self.assertIn('SHA256 mismatch', rerun.stderr)

    def test_mismatched_pin_prevents_module_snapshot_and_stage_creation(self):
        for pin in ['0' * 64, 'A' * 64, 'short']:
            with self.assertRaisesRegex(ValueError, 'SHA256'):
                deliver(self.contract, self.temp / 'missing-before', self.temp / 'missing-after', self.output, pin)
            self.assertEqual(list(self.temp.iterdir()), [])
        pin = hashlib.sha256(self.contract.read_bytes()).hexdigest()
        changed = self.temp / 'changed.json'
        changed.write_bytes(self.contract.read_bytes() + b'\n')
        run = subprocess.run([sys.executable, str(ROOT / 'deliver_repair.py'), '--contract-sha256', pin,
                              str(changed), 'missing-before', 'missing-after', str(self.output)],
                             capture_output=True, text=True)
        self.assertEqual(run.returncode, 1)
        self.assertEqual(run.stdout, '')
        self.assertIn('SHA256 mismatch', run.stderr)
        self.assertEqual(list(self.temp.iterdir()), [changed])

    def test_unverified_repairs_do_not_create_output(self):
        for before, after in [(self.after, self.after), (self.before, self.before)]:
            with self.assertRaisesRegex(ValueError, 'Repair not verified'):
                deliver(self.contract, before, after, self.output)
            self.assertFalse(self.output.exists())

    def test_relative_dependency_is_not_silently_accepted(self):
        module = self.temp / 'dependent.js'
        dependency = self.temp / 'dependency.js'
        dependency.write_text('export const total = "0.00";')
        module.write_text('import {total} from "./dependency.js"; export function orderTotal(){return total;}')
        with self.assertRaisesRegex(ValueError, 'Repair not verified'):
            deliver(self.contract, self.before, module, self.output)
        self.assertFalse(self.output.exists())

    def test_truncated_exception_prefix_cannot_create_handoff(self):
        contract = self.temp / 'exception.json'
        contract.write_text(json.dumps({'version': 1, 'exportName': 'repair', 'timeoutMs': 2000,
            'cases': [{'name': 'exact error', 'args': [],
                       'expected': {'error': {'name': 'Error', 'message': 'x' * 2000}}}]}))
        before = self.temp / 'original.mjs'
        after = self.temp / 'repair.mjs'
        before.write_text('export const repair=()=>0;')
        after.write_text('export function repair(){throw new Error("x".repeat(2001));}')
        with self.assertRaisesRegex(ValueError, 'Repair not verified'):
            deliver(contract, before, after, self.output)
        self.assertFalse(self.output.exists())

    def test_ambiguous_contract_refuses_handoff(self):
        ambiguous = self.temp / 'ambiguous.json'
        ambiguous.write_text(self.contract.read_text().replace('"version": 1,', '"version": 1, "version": 1,'))
        with self.assertRaisesRegex(ValueError, 'Repair not verified'):
            deliver(ambiguous, self.before, self.after, self.output)
        self.assertFalse(self.output.exists())

    def test_invalid_contract_never_snapshots_implementations(self):
        for data in [b'\xff', b'{"version":1,"version":1}', b'{}']:
            invalid = self.temp / 'invalid-contract.json'
            invalid.write_bytes(data)
            real_snapshot = deliver_repair.snapshot
            reads = []
            def recording_snapshot(path, limit):
                reads.append(Path(path))
                return real_snapshot(path, limit)
            with patch('deliver_repair.snapshot', recording_snapshot):
                with self.assertRaisesRegex(ValueError, 'invalid contract'):
                    deliver(invalid, self.before, self.after, self.output)
            self.assertNotIn(self.before, reads)
            self.assertNotIn(self.after, reads)
            self.assertFalse(self.output.exists())

    @unittest.skipUnless(hasattr(os, 'mkfifo'), 'POSIX FIFO unavailable')
    def test_fifo_contract_and_delivery_inputs_fail_promptly(self):
        fifo = self.temp / 'input.fifo'
        os.mkfifo(fifo)
        result = subprocess.run([shutil.which('node'), str(ROOT / 'contract-review.js'),
                                 str(fifo), str(self.before), str(self.after)],
                                capture_output=True, text=True, timeout=3)
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertIn('regular file', result.stderr)
        self.assertEqual(result.stdout, '')
        with self.assertRaisesRegex(ValueError, 'regular file'):
            deliver(fifo, self.before, self.after, self.output)
        self.assertFalse(self.output.exists())

    def test_existing_delivery_and_invalid_contract_preserved(self):
        self.output.mkdir()
        sentinel = self.output / 'do-not-overwrite'
        sentinel.write_text('preserve')
        with self.assertRaisesRegex(ValueError, 'Output must not exist'):
            deliver(self.contract, self.before, self.after, self.output)
        self.assertEqual(sentinel.read_text(), 'preserve')
        invalid = self.temp / 'invalid.json'
        invalid.write_bytes(b'\xff')
        with self.assertRaisesRegex(ValueError, 'Repair not verified'):
            deliver(invalid, self.before, self.after, self.temp / 'invalid-delivery')
        self.assertFalse((self.temp / 'invalid-delivery').exists())

if __name__ == '__main__':
    unittest.main()

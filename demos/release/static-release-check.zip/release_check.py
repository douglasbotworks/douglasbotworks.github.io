"""Offline static build inventory, literal asset checks and deterministic packaging."""
import argparse
import hashlib
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
from urllib.parse import unquote, urlsplit
import zipfile

MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 256 * 1024 * 1024
MAX_FILES = 10000
HARD_MAX_FILES = 50000
BLOCKED = {'.git', '.douglas', 'node_modules', '__pycache__'}


def forbidden(name):
    lower = name.lower()
    return (lower in BLOCKED or lower == '.env' or lower.startswith('.env.')
            or lower.endswith(('.pem', '.key', '.p12', '.pfx'))
            or lower in {'credentials.json', 'oauth.json', 'token.json'})


def member_name(name):
    """One filename contract for snapshots, ZIP writing and recipient verification."""
    return (isinstance(name, str) and bool(name) and not name.startswith('/')
            and '\\' not in name and '\x00' not in name
            and all(p not in {'', '.', '..'} and not forbidden(p) for p in name.split('/')))


ASCII_SPACE = ' \t\n\r\f'


def unsupported_encoding(labels):
    # WHATWG UTF-8 labels only. This is a conservative declaration check,
    # not browser encoding sniffing or HTTP-header/BOM precedence simulation.
    return any(label.strip(ASCII_SPACE).lower() not in
               {'utf-8', 'utf8', 'unicode-1-1-utf-8'} for label in labels)


def srcset_assets(text):
    """Extract ordinary candidates using HTML's URL/descriptor boundaries.

    Commas inside URLs are literal; only trailing commas or descriptor commas
    delimit candidates. Unsupported descriptors require manual review.
    This does not choose an image or validate sizes/media/image dimensions.
    """
    refs, issues = [], []
    position = 0
    while position < len(text):
        start = position
        while position < len(text) and text[position] in ASCII_SPACE + ',':
            position += 1
        if ',' in text[start:position]:
            issues.append(('manual-srcset-check', 'Extra srcset separator requires review'))
        if position == len(text):
            break
        start = position
        while position < len(text) and text[position] not in ASCII_SPACE:
            position += 1
        value = text[start:position]
        descriptors = []
        if value.endswith(','):
            stripped = value.rstrip(',')
            if len(value) - len(stripped) > 1:
                issues.append(('manual-srcset-check', 'Extra srcset separator requires review'))
            value = stripped
        else:
            current, in_parens = '', False
            while position < len(text):
                char = text[position]
                position += 1
                if in_parens:
                    current += char
                    if char == ')':
                        in_parens = False
                elif char == ',':
                    break
                elif char in ASCII_SPACE:
                    if current:
                        descriptors.append(current)
                        current = ''
                else:
                    current += char
                    if char == '(':
                        in_parens = True
            if current:
                descriptors.append(current)
        ordinary = not descriptors
        if len(descriptors) == 1:
            descriptor = descriptors[0]
            # Syntactic subset only, without converting arbitrarily large numbers.
            if re.fullmatch(r'[0-9]+w', descriptor):
                ordinary = any(c != '0' for c in descriptor[:-1])
            elif re.fullmatch(r'(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?x', descriptor):
                ordinary = True
        if value and ordinary:
            refs.append(value)
        else:
            issues.append(('manual-srcset-check', 'Unsupported srcset candidate: ' + value + ' ' + ' '.join(descriptors)))
    return refs, issues


class FragmentTargets(HTMLParser):
    """Literal document anchors only; no DOM execution or tree reconstruction."""
    CDATA_CONTENT_ELEMENTS = ('script', 'style', 'textarea', 'title', 'xmp',
                              'iframe', 'noembed', 'noframes')

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.targets = set()
        self.duplicates = set()
        self.navigation = []
        self.template_depth = 0
        self.unsupported = False

    def handle_starttag(self, tag, attrs):
        if tag in {'noscript', 'plaintext'}:
            self.unsupported = True
        if self.template_depth:
            if tag == 'template':
                self.template_depth += 1
            return
        first = {}
        for name, value in attrs:
            first.setdefault(name, value)
        if tag in {'a', 'area'} and first.get('href'):
            self.navigation.append(first['href'])
        if tag == 'template':
            self.template_depth += 1
        element_targets = set()
        if first.get('id'):
            element_targets.add(first['id'])
        if tag == 'a' and first.get('name'):
            element_targets.add(first['name'])
        self.duplicates.update(self.targets.intersection(element_targets))
        self.targets.update(element_targets)

    def handle_endtag(self, tag):
        if tag == 'template' and self.template_depth:
            self.template_depth -= 1

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag in {'template', 'script', 'style', 'textarea', 'title', 'xmp',
                   'iframe', 'noembed', 'noframes'}:
            self.unsupported = True


class Assets(HTMLParser):
    # Apparent tags in these elements are text, not asset-bearing children.
    CDATA_CONTENT_ELEMENTS = FragmentTargets.CDATA_CONTENT_ELEMENTS

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.refs = []
        self.navigation = []
        self.base = False
        self.unsupported = False
        self.issues = []
        self.inline_styles = []
        self._style = None
        self.template_depth = 0
        self.ambiguous_context = False
        self.encoding_labels = []

    def handle_starttag(self, tag, attrs):
        if tag in {'noscript', 'plaintext'}:
            self.ambiguous_context = True
        if tag == 'template':
            self.template_depth += 1
        # HTML keeps the first occurrence and discards later duplicate attributes.
        # dict(attrs) would instead check a value the browser never uses.
        first = {}
        for name, value in attrs:
            if name in first:
                self.issues.append(('duplicate-html-attribute', tag + ' ' + name + ': first value retained; repair duplicate attribute'))
            else:
                first[name] = value
        attrs = first
        if tag == 'meta':
            if 'charset' in attrs:
                self.encoding_labels.append(attrs['charset'] or '')
            elif (attrs.get('http-equiv') or '').strip(ASCII_SPACE).lower() == 'content-type':
                match = re.search(r'charset\s*=\s*[\"\']?([^\s;\"\']*)',
                                  attrs.get('content') or '', re.IGNORECASE)
                if match:
                    self.encoding_labels.append(match.group(1))
        if tag == 'base':
            self.base = True
        for attr in ('src', 'poster'):
            if attrs.get(attr):
                self.refs.append(attrs[attr])
        if tag in {'a', 'area'} and attrs.get('href') and not self.template_depth:
            self.navigation.append(attrs['href'])
        if tag == 'link' and attrs.get('href'):
            self.refs.append(attrs['href'])
        candidate_attr = 'srcset' if tag in {'img', 'source'} else 'imagesrcset' if tag == 'link' else None
        if candidate_attr and attrs.get(candidate_attr):
            refs, issues = srcset_assets(attrs[candidate_attr])
            self.refs.extend(refs)
            self.issues.extend(issues)
        if attrs.get('style'):
            self.inline_styles.append(attrs['style'])
        if tag == 'style':
            if (attrs.get('type') or '').strip().lower() in {'', 'text/css'}:
                self._style = []
            else:
                self.unsupported = True

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag == 'style':
            # HTMLParser does not apply browser raw-text semantics to this
            # malformed self-closing form; require manual review.
            self._style = None
            self.unsupported = True
        elif tag in self.CDATA_CONTENT_ELEMENTS or tag == 'template':
            # HTML ignores self-closing flags here; HTMLParser does not.
            self.unsupported = True

    def handle_data(self, data):
        if self._style is not None:
            self._style.append(data)

    def handle_endtag(self, tag):
        if tag == 'template' and self.template_depth:
            self.template_depth -= 1
        if tag == 'style' and self._style is not None:
            self.inline_styles.append(''.join(self._style))
            self._style = None


def read_regular(path):
    # No following symlinks; also validate the opened file before reading.
    fd = os.open(str(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE:
            raise ValueError('Unsupported file or file over 32 MiB: ' + path.name)
        data = stream.read(MAX_FILE + 1)
        if len(data) > MAX_FILE:
            raise ValueError('File grew beyond 32 MiB: ' + path.name)
        return data


def snapshot(root, max_files=MAX_FILES):
    if type(max_files) is not int or not 1 <= max_files <= HARD_MAX_FILES:
        raise ValueError('max_files must be an integer from 1 to 50000')
    root = Path(os.path.abspath(str(root)))
    if any(forbidden(p) for p in root.parts):
        raise ValueError('Forbidden build path')
    # Reject all symlink path components, including the input directory.
    for parent in [root] + list(root.parents):
        if parent.is_symlink():
            raise ValueError('Symlink build paths are unsupported')
    if not root.is_dir():
        raise ValueError('Build must be a directory')
    contents = {}
    total = 0
    def traversal_error(error):
        raise error
    for directory, dirs, files in os.walk(root, followlinks=False, onerror=traversal_error):
        for name in dirs + files:
            path = Path(directory) / name
            if forbidden(name):
                raise ValueError('Forbidden entry; provide a clean build: ' + str(path.relative_to(root)))
            if path.is_symlink():
                raise ValueError('Symlink entry: ' + str(path.relative_to(root)))
            if not member_name(path.relative_to(root).as_posix()):
                raise ValueError('Unsupported package path: ' + str(path.relative_to(root)))
        for name in sorted(files):
            if len(contents) >= max_files:
                raise ValueError('Build exceeds {} files'.format(max_files))
            path = Path(directory) / name
            data = read_regular(path)
            total += len(data)
            if total > MAX_TOTAL:
                raise ValueError('Build exceeds 256 MiB')
            contents[path.relative_to(root).as_posix()] = data
    return dict(sorted(contents.items()))


def css_assets(text):
    """Extract bounded literal references; skip comments and unrelated strings.

    Escaped CSS syntax requires manual review rather than a guessed filename.
    This is deliberately not a complete CSS tokenizer or validator.
    """
    refs, issues = [], []
    token = re.compile(r'/\*|[\"\x27]|(?<![\w-])url\(|(?<![\w-])@import\b|\\', re.I)
    position = 0
    def string(start):
        quote, end, escaped = text[start], start + 1, False
        while end < len(text):
            if text[end] == '\\':
                escaped = True
                end += 2
            elif text[end] == quote:
                return text[start + 1:end], end + 1, escaped, True
            elif text[end] in '\r\n\f':
                return '', end + 1, escaped, False
            else:
                end += 1
        return '', end, escaped, False
    while True:
        match = token.search(text, position)
        if not match:
            break
        value = match.group()
        position = match.end()
        if value == '/*':
            end = text.find('*/', position)
            if end < 0:
                issues.append(('invalid-css-asset', 'Unterminated CSS comment'))
                break
            position = end + 2
        elif value in {'"', "'"}:
            _, position, _, _ = string(match.start())
        elif value == '\\':
            issues.append(('manual-css-escape', 'Escaped CSS syntax requires manual asset review'))
            position += 1
        else:
            while position < len(text):
                if text[position] in ' \t\r\n\f':
                    position += 1
                elif text.startswith('/*', position) and value.lower() == '@import':
                    end = text.find('*/', position + 2)
                    if end < 0:
                        issues.append(('invalid-css-asset', 'Unterminated CSS comment'))
                        position = len(text)
                        break
                    position = end + 2
                else:
                    break
            is_url = value.lower() == 'url('
            if position < len(text) and text[position] in {'"', "'"}:
                ref, position, escaped, valid = string(position)
                if is_url:
                    # A quoted url() is a function containing a string token.
                    # Comments between that token and ')' are discarded, unlike
                    # comment-looking bytes inside an unquoted URL token.
                    while position < len(text):
                        if text[position] in ' \t\r\n\f':
                            position += 1
                        elif text.startswith('/*', position):
                            end = text.find('*/', position + 2)
                            position = end + 2 if end >= 0 else len(text)
                        else:
                            break
                    valid = valid and position < len(text) and text[position] == ')'
                    if valid:
                        position += 1
            elif is_url:
                start, escaped = position, False
                while position < len(text) and text[position] != ')':
                    if text[position] == '\\':
                        escaped = True
                        position += 2
                    else:
                        position += 1
                ref = text[start:position].strip(ASCII_SPACE)
                valid = position < len(text) and not any(c in ref for c in '\"\x27(\r\n\f\t ')
                position += 1
            else:
                # @import url(...) is consumed by the next iteration.
                continue
            if not valid:
                issues.append(('invalid-css-asset', 'Malformed literal CSS asset reference'))
            elif escaped:
                issues.append(('manual-css-escape', 'Escaped CSS asset reference requires manual review'))
            elif ref:
                refs.append(ref)
    return refs, issues


def strict_json(text):
    """Reject ambiguous keys, non-JSON constants and unsupported nesting."""
    def object_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON object key')
            result[key] = value
        return result

    def constant(value):
        raise ValueError('Non-JSON numeric constant')

    try:
        value = json.loads(text, object_pairs_hook=object_pairs, parse_constant=constant)
    except RecursionError as exc:
        raise ValueError('JSON nesting exceeds parser capacity') from exc
    # Escaped lone surrogates decode in Python but cannot enter UTF-8 reports.
    pending = [value]
    while pending:
        item = pending.pop()
        if isinstance(item, str):
            if any(0xD800 <= ord(char) <= 0xDFFF for char in item):
                raise ValueError('JSON contains an unpaired Unicode surrogate')
        elif isinstance(item, dict):
            pending.extend(item.keys())
            pending.extend(item.values())
        elif isinstance(item, list):
            pending.extend(item)
    return value


def extension_findings(contents):
    findings = []
    def add(code, value):
        findings.append(dict(level='error', code=code, source='manifest.json', value=value))
    try:
        manifest = strict_json(contents['manifest.json'].decode('utf-8'))
        if not isinstance(manifest, dict):
            raise ValueError('Manifest must be an object')
    except (KeyError, ValueError, UnicodeError):
        add('invalid-manifest', 'Missing or invalid UTF-8 JSON manifest object')
        return findings
    if type(manifest.get('manifest_version')) is not int or manifest['manifest_version'] != 3:
        add('manifest-version', 'This checker supports Manifest V3 only')
    if not isinstance(manifest.get('name'), str) or not manifest['name'].strip():
        add('manifest-name', 'Nonempty name required')
    version = manifest.get('version')
    if (not isinstance(version, str) or not re.fullmatch(r'(0|[1-9][0-9]{0,4})(\.(0|[1-9][0-9]{0,4})){0,3}', version)
            or any(int(p) > 65535 for p in version.split('.')) or not any(int(p) for p in version.split('.'))):
        add('manifest-version-string', 'Expected 1–4 integer components, 0–65535, not all zero')
    refs = []
    def path(value):
        if not isinstance(value, str) or not value:
            add('manifest-asset-type', 'Expected nonempty local asset path')
        else:
            refs.append(value)
    def obj(value):
        if not isinstance(value, dict):
            add('manifest-field-type', 'Expected object for supported manifest field')
            return {}
        return value
    def icons(value):
        if isinstance(value, str):
            path(value)
        else:
            for value in obj(value).values():
                path(value)
    if 'icons' in manifest:
        icons(manifest['icons'])
    for field in ('background', 'action', 'options_ui', 'chrome_url_overrides', 'side_panel'):
        if field not in manifest:
            continue
        entry = obj(manifest[field])
        for key in {'background': ['service_worker'], 'action': ['default_popup'], 'options_ui': ['page'],
                    'chrome_url_overrides': ['newtab', 'history', 'bookmarks'], 'side_panel': ['default_path']}[field]:
            if key in entry:
                path(entry[key])
        if 'default_icon' in entry:
            icons(entry['default_icon'])
    if 'options_page' in manifest:
        path(manifest['options_page'])
    scripts = manifest.get('content_scripts', [])
    if not isinstance(scripts, list):
        add('manifest-field-type', 'content_scripts must be a list')
        scripts = []
    for entry in scripts:
        entry = obj(entry)
        for key in ('js', 'css'):
            values = entry.get(key, [])
            if not isinstance(values, list):
                add('manifest-field-type', key + ' must be a list')
                continue
            for value in values:
                path(value)
    for value in refs:
        # Manifest paths are package filenames, not URLs. No glob support here.
        if (value.startswith('/') or '\\' in value or '\x00' in value
                or '..' in value.split('/') or any(forbidden(p) for p in value.split('/'))):
            add('invalid-manifest-path', value)
        elif value not in contents:
            add('missing-manifest-asset', value)
    return findings


def deployment_base(value):
    if (not isinstance(value, str) or not value.startswith('/')
            or any(c in value for c in '\\?#%\x00')
            or any(c.isspace() for c in value)):
        raise ValueError('Base path must be an absolute URL path without escapes, query or fragment')
    body = value[1:]
    if body.endswith('/'):
        body = body[:-1]
    parts = body.split('/') if body else []
    if value.startswith('//'):
        raise ValueError('Base path cannot be a protocol-relative URL')
    if any(p in {'', '.', '..'} or forbidden(p) for p in parts):
        raise ValueError('Base path must have ordinary nonempty directory segments')
    return '/' + '/'.join(parts) + ('/' if parts else '')


def audit(contents, mode='static', base_path='/', check_navigation=False, check_fragments=False):
    if check_fragments and not check_navigation:
        raise ValueError('Fragment checks require --check-navigation')
    base_path = deployment_base(base_path)
    if mode == 'extension' and base_path != '/':
        raise ValueError('Extension mode does not support a deployment base path')
    base_parts = [p for p in base_path.split('/') if p]
    findings = []
    def add(level, code, source, value):
        findings.append(dict(level=level, code=code, source=source, value=value))
    fragment_cache = {}
    def check_fragment(source, target, fragment, value):
        if not fragment:
            return
        if ':~:' in fragment:
            add('warning', 'manual-fragment-check', source, value)
            return
        if PurePosixPath(target).suffix.lower() not in {'.html', '.htm'}:
            add('warning', 'manual-fragment-check', source, value)
            return
        if target not in fragment_cache:
            anchors = FragmentTargets()
            try:
                target_text = contents[target].decode('utf-8', errors='strict')
                encoding = Assets()
                encoding.feed(target_text)
                encoding.close()
                if unsupported_encoding(encoding.encoding_labels):
                    anchors.unsupported = True
                anchors.feed(target_text)
                anchors.close()
            except UnicodeError:
                anchors.unsupported = True
            if anchors.template_depth:
                anchors.unsupported = True
            fragment_cache[target] = anchors
        anchors = fragment_cache[target]
        if anchors.unsupported:
            add('warning', 'manual-fragment-check', source, value)
            return
        # HTML tries the literal fragment before percent-decoding UTF-8.
        decoded = unquote(fragment, errors='replace')
        if fragment not in anchors.targets and decoded not in anchors.targets and decoded.lower() != 'top':
            add('error', 'missing-navigation-fragment', source, value)
    if mode == 'extension':
        findings.extend(extension_findings(contents))
    elif 'index.html' not in contents:
        add('error', 'missing-entry', '.', 'index.html')
    for source, data in contents.items():
        suffix = PurePosixPath(source).suffix.lower()
        if suffix not in {'.html', '.htm', '.css'}:
            continue
        try:
            text = data.decode('utf-8', errors='strict')
        except UnicodeError:
            add('error', 'invalid-utf8', source, 'Expected UTF-8')
            continue
        if suffix in {'.html', '.htm'}:
            parser = Assets()
            parser.feed(text)
            parser.close()
            if unsupported_encoding(parser.encoding_labels):
                add('warning', 'manual-text-encoding', source,
                    'Non-UTF-8 or empty HTML encoding declaration; UTF-8 reference checks skipped')
                continue
            if parser.ambiguous_context:
                add('warning', 'manual-asset-check', source,
                    'Asset and navigation resolution skipped: noscript or plaintext requires browser review')
                continue
            if parser._style is not None:
                add('warning', 'manual-asset-check', source, 'Unterminated style element requires review')
            if parser.base:
                add('warning', 'base-not-resolved', source, 'Asset resolution skipped: base element requires browser review')
                continue
            refs = parser.refs
            for inline in parser.inline_styles:
                inline_refs, inline_issues = css_assets(inline)
                refs.extend(inline_refs)
                for code, value in inline_issues:
                    add('warning' if code == 'manual-css-escape' else 'error', code, source, value)
            for code, value in parser.issues:
                add('warning', code, source, value)
            if parser.unsupported or parser.template_depth:
                add('warning', 'manual-asset-check', source, 'Unsupported style or HTML parsing context requires manual review')
        else:
            charset = re.match(r'\A\ufeff?@charset "([^"\r\n]*)";', text)
            if charset and unsupported_encoding([charset.group(1)]):
                add('warning', 'manual-text-encoding', source,
                    'Non-UTF-8 CSS encoding declaration; UTF-8 reference checks skipped')
                continue
            refs, issues = css_assets(text)
            for code, value in issues:
                add('warning' if code == 'manual-css-escape' else 'error', code, source, value)
        references = [(value, False) for value in refs]
        if check_navigation and suffix in {'.html', '.htm'}:
            if check_fragments:
                source_anchors = FragmentTargets()
                source_anchors.feed(text)
                source_anchors.close()
                if source_anchors.template_depth:
                    source_anchors.unsupported = True
                fragment_cache[source] = source_anchors
                if source_anchors.unsupported:
                    add('warning', 'manual-fragment-check', source, 'Navigation skipped: unsupported HTML parsing context')
                else:
                    for target_value in sorted(source_anchors.duplicates):
                        add('warning', 'duplicate-fragment-target', source, target_value)
                    references.extend((value, True) for value in source_anchors.navigation)
            else:
                references.extend((value, True) for value in parser.navigation)
        for value, navigation in references:
            try:
                # URL preprocessing trims C0/space, not Unicode whitespace.
                # NBSP and other Unicode spaces are meaningful filename bytes.
                prepared = value.strip(''.join(chr(c) for c in range(33)))
                prepared = prepared.translate(str.maketrans('', '', '\t\n\r'))
                # Additional leading slashes also introduce an HTTPS authority.
                # Remote availability cannot be inferred from local inventory.
                if prepared.startswith('//'):
                    add('warning', 'remote-navigation' if navigation else 'remote-asset', source, value)
                    continue
                url = urlsplit(prepared)
                if url.scheme or url.netloc:
                    if url.scheme in {'http', 'https'} or url.netloc:
                        add('warning', 'remote-navigation' if navigation else 'remote-asset', source, value)
                    elif not navigation and url.scheme != 'data':
                        # A host-file, object URL or custom scheme is not a
                        # portable inventory match. Never dereference it.
                        add('warning', 'manual-asset-scheme', source, value)
                    continue
                if not url.path:
                    if navigation and check_fragments:
                        check_fragment(source, source, url.fragment, value)
                    continue
                # Encoded separators remain within URL segments. Decoding them
                # before splitting would invent directories and falsely approve
                # a different resource; server decoding policies are out of scope.
                if re.search(r'%2f|%5c', url.path, re.IGNORECASE):
                    raise ValueError('Encoded path separator requires repair')
                # Empty URL path segments are significant. Filesystem-style
                # collapsing would approve a different URL (and dot resolution
                # can also change). Deployment routing needs separate review.
                if '//' in url.path:
                    add('warning', 'manual-navigation-path' if navigation else 'manual-asset-path', source, value)
                    continue
                path = unquote(url.path, errors='strict')
                if '\\' in path or '\x00' in path:
                    raise ValueError('Unsupported path')
                parts = [] if path.startswith('/') else base_parts + list(PurePosixPath(source).parent.parts)
                for part in path.split('/'):
                    if part in {'', '.'}:
                        continue
                    if part == '..':
                        if not parts:
                            raise ValueError('Path escapes build')
                        parts.pop()
                    else:
                        parts.append(part)
                if any(forbidden(p) for p in parts):
                    raise ValueError('Forbidden asset path')
                if parts[:len(base_parts)] != base_parts:
                    add('error', 'outside-deployment-base', source, value)
                    continue
                target = '/'.join(parts[len(base_parts):])
                if path.endswith('/') or path.split('/')[-1] in {'.', '..'}:
                    target = (target + '/' if target else '') + 'index.html'
                if target not in contents:
                    add('error', 'missing-navigation-target' if navigation else 'missing-asset', source, value)
                elif navigation and check_fragments:
                    check_fragment(source, target, url.fragment, value)
            except (ValueError, UnicodeError):
                add('error', 'invalid-navigation-path' if navigation else 'invalid-asset-path', source, value)
    return dict(schema_version=1, mode=mode, base_path=base_path, check_navigation=check_navigation, check_fragments=check_fragments, files=[dict(path=p, bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
                for p, b in contents.items()], total_bytes=sum(map(len, contents.values())),
                findings=findings, errors=sum(f['level'] == 'error' for f in findings),
                warnings=sum(f['level'] == 'warning' for f in findings),
                limits='UTF-8 text only; conflicting HTML meta and initial CSS charset declarations require manual review; server/inherited encoding and browser sniffing are not simulated. Literal HTML src/poster/link href, ordinary img/source srcset and link imagesrcset candidates, and CSS url/import in stylesheets, style attributes and closed CSS style elements only; duplicate HTML attributes warn and keep their first value; srcset sizes/media/selection and unsupported descriptors require manual review; CSS escapes require manual review and other CSS asset functions are not analyzed. Apparent child tags in supported HTML text elements are excluded; literal template assets remain checked for later activation. Extension mode additionally checks basic MV3 name/version and asset paths in icons, background service_worker, action popup/icon, options pages, side_panel, chrome_url_overrides and content_scripts js/css. Other manifest fields, resource globs, locale files, permissions and store policies are not validated. Optional a/area href file-target checks: ' + ('enabled' if check_navigation else 'disabled') + '; trailing-slash and final dot-segment paths require index.html; navigation in template contents is excluded. Optional literal HTML ID/named-anchor checks: ' + ('enabled' if check_fragments else 'disabled') + '; raw and UTF-8 percent-decoded fragments and top supported; duplicate literal target values on different elements warn once per page/value; template contents excluded; text directives, non-HTML fragments and unsupported parsing contexts require manual review. DOM-generated targets, browser tree reconstruction, query behavior, extensionless rewrites, server routes and remote navigation availability are not validated. No JavaScript execution, module imports, fetch calls, browser gameplay, accessibility, license or security validation. Deployment base path: ' + base_path + '. References outside this path cannot be verified from the supplied build. External URLs are not fetched.')


def render(report):
    esc = lambda value: html.escape(str(value), quote=True)
    rows = ''.join('<tr>' + ''.join('<td>' + esc(f[k]) + '</td>' for k in ('level', 'code', 'source', 'value')) + '</tr>' for f in report['findings'])
    gate = report.get('release_gate')
    gate_text = ('Packaging gate: {}. Warnings block packaging: {}.'.format(
        'passed' if gate['passed'] else 'blocked',
        'yes' if gate['require_no_warnings'] else 'no') if gate else 'Packaging policy not recorded.')
    return ('<!doctype html><html lang="en"><meta charset="utf-8">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">'
            '<meta name="viewport" content="width=device-width,initial-scale=1"><title>Static release check</title>'
            '<style>body{{font:16px system-ui;margin:2rem;max-width:1000px}}td,th{{border:1px solid #aaa;padding:.5rem;overflow-wrap:anywhere}}table{{border-collapse:collapse;width:100%}}</style>'
            '<h1>Static release check</h1><p>{} files, {} bytes. {} errors; {} warnings.</p><p>{}</p><p>{}</p>'
            '<table><tr><th>Level</th><th>Check</th><th>Source</th><th>Reference</th></tr>{}</table></html>').format(
                len(report['files']), report['total_bytes'], report['errors'], report['warnings'], esc(gate_text), esc(report['limits']), rows)


def delivery_note(report):
    """Recipient instructions; untrusted finding strings stay in escaped HTML reports."""
    gate = report['release_gate']
    lines = ['# Release review handoff', '',
             '{} files; {} bytes; {} errors; {} warnings.'.format(
                 len(report['files']), report['total_bytes'], report['errors'], report['warnings']), '',
             'Packaging gate: **{}**.'.format('passed' if gate['passed'] else 'blocked'),
             'Warnings block packaging: {}.'.format('yes' if gate['require_no_warnings'] else 'no'), '',
             'Local navigation file targets checked: {}.'.format('yes' if report['check_navigation'] else 'no'),
             'Literal HTML section anchors checked: {}.'.format('yes' if report.get('check_fragments') else 'no'), '',
             'Read report.html for exact findings and report.json for the inventory and content hashes.',
             'Resolve every error. Review every warning, including unsupported cases and remote resources.',
             'After repairs, rerun against the final build into a fresh output directory.', '']
    if 'archive_sha256' in report:
        lines += ['release.zip contains the exact reviewed bytes.', '',
                  'Archive SHA256: ' + report['archive_sha256'], '',
                  'With the separately supplied Static Release Check tool, run:', '',
                  '```sh', 'python3 verify_release.py /path/to/report.json /path/to/release.zip', '```', '',
                  'Verification proves consistency with the report. Receive the report through a trusted channel.']
    else:
        lines += ['No release ZIP was delivered. ' + (
            'The packaging gate blocked it.' if not gate['passed'] else 'Packaging was not requested.')]
    lines += ['', 'A passed gate covers only the bounded static checks. Browser/runtime behavior,',
              'store acceptance, security, accessibility and asset rights require separate review.',
              'The full scope and deployment base path are recorded in report.json and report.html.', '']
    return '\n'.join(lines)


def write_zip(path, contents):
    # All members come from the same in-memory bytes used by the report.
    # Validate before creating output: ZipInfo silently truncates NUL filenames.
    if any(not member_name(name) for name in contents):
        raise ValueError('Unsupported package path')
    with open(path, 'xb') as stream:
        with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in contents.items():
                item = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
                item.compress_type = zipfile.ZIP_DEFLATED
                item.external_attr = 0o100644 << 16
                archive.writestr(item, data)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('build')
    parser.add_argument('--output', required=True, help='New output directory, outside build')
    parser.add_argument('--zip', action='store_true', help='Package only when the selected gate passes')
    parser.add_argument('--require-no-warnings', action='store_true',
                        help='Block packaging and return 2 when manual-review warnings remain')
    parser.add_argument('--check-navigation', action='store_true',
                        help='Check literal a/area href file targets; trailing slash requires index.html')
    parser.add_argument('--check-fragments', action='store_true',
                        help='With --check-navigation, check literal HTML IDs and named anchors')
    parser.add_argument('--mode', choices=('static', 'extension'), default='static')
    parser.add_argument('--base-path', default='/', help='Static site deployment directory, e.g. /games/demo/ (default: /)')
    parser.add_argument('--max-files', type=int, default=MAX_FILES,
                        help='Inventory file cap, 1–50000 (default: 10000); byte caps remain fixed')
    args = parser.parse_args(argv)
    try:
        root = Path(os.path.abspath(args.build))
        output = Path(os.path.abspath(args.output))
        if any(forbidden(p) for p in output.parts):
            raise ValueError('Forbidden output path')
        # Resolve output parents only to prevent symlink redirection into input.
        resolved_output = output.resolve()
        if resolved_output == root or root in resolved_output.parents:
            raise ValueError('Output must be outside the build')
        base_path = deployment_base(args.base_path)
        if args.mode == 'extension' and base_path != '/':
            raise ValueError('Extension mode does not support a deployment base path')
        contents = snapshot(root, args.max_files)
        report = audit(contents, args.mode, base_path, args.check_navigation, args.check_fragments)
        report['snapshot_limits'] = dict(max_files=args.max_files, max_file_bytes=MAX_FILE,
                                       max_total_bytes=MAX_TOTAL)
        report['release_gate'] = dict(require_no_warnings=args.require_no_warnings,
                                      passed=not report['errors'] and not (args.require_no_warnings and report['warnings']))
        output.mkdir(parents=False, exist_ok=False)
        if args.zip and report['release_gate']['passed']:
            archive = output / 'release.zip'
            write_zip(archive, contents)
            report['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
        (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        (output / 'report.html').write_text(render(report), encoding='utf-8')
        (output / 'DELIVERY.md').write_text(delivery_note(report), encoding='utf-8')
        print('{} files; {} errors; {} warnings; gate {}. Reports: {}'.format(
            len(contents), report['errors'], report['warnings'],
            'passed' if report['release_gate']['passed'] else 'blocked', output))
        return 0 if report['release_gate']['passed'] else 2
    except (OSError, ValueError) as exc:
        print('Release check failed: ' + str(exc))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

// Deliberately faulty synthetic sample: completion order controls visible state.
export function requestTrace(events) {
  let state = {requestId: 0, status: 'idle', data: null, error: null};
  for (const event of events) {
    if (event.type === 'start') state = {requestId: event.id, status: 'loading', data: null, error: null};
    if (event.type === 'success') state = {requestId: event.id, status: 'success', data: event.data, error: null};
    if (event.type === 'failure') state = {requestId: event.id, status: 'error', data: null, error: event.error};
    if (event.type === 'cancel') state = {requestId: event.id, status: 'idle', data: null, error: null};
  }
  return state;
}

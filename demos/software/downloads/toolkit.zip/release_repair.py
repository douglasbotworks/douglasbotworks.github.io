"""Build, pack and verify a pinned standalone repair in an exclusive directory."""
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

from deliver_repair import deliver
from handoff_archive import pack, verify


def release(contract, original, repaired, output, expected):
    if not isinstance(expected, str) or not re.fullmatch(r'[a-f0-9]{64}', expected):
        raise ValueError('An inspected lowercase contract SHA256 is required')
    root = Path(output).absolute()
    # Reserve one private release directory. Failed releases remain diagnostic;
    # only RECEIPT.json written last marks completion.
    root.mkdir(mode=0o700)
    delivery = deliver(contract, original, repaired, root / 'handoff',
                       expected_contract_sha256=expected)
    archive = root / 'handoff.zip'
    packed = pack(root / 'handoff', archive)
    checked = verify(archive, packed['sha256'])
    if checked['manifestSha256'] != delivery['manifestSha256']:
        raise ValueError('Archive and delivered manifest differ')
    receipt = {
        'version': 1, 'complete': True, 'contractSha256': expected,
        'archive': 'handoff.zip', 'archiveSha256': checked['sha256'],
        'manifestSha256': checked['manifestSha256'],
        'members': checked['members'], 'summary': delivery['summary'],
        'fixtureVerified': True, 'archiveContentConsistent': True,
        'customerAccepted': False,
    }
    with (root / 'RECEIPT.json').open('x') as destination:
        destination.write(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    return receipt


if __name__ == '__main__':
    try:
        if len(sys.argv) != 6:
            raise ValueError('Usage: release_repair.py contract.json before.js after.js NEW_DIRECTORY INSPECTED_SHA256')
        print(json.dumps(release(*sys.argv[1:]), sort_keys=True))
    except (ValueError, OSError, KeyError, subprocess.SubprocessError,
            zipfile.BadZipFile, RuntimeError, RecursionError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)

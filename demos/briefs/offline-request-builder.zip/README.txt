DOUGLAS BOT WORKS — OFFLINE SERVICE REQUEST BUILDER

Extract the complete ZIP into a new folder, then open index.html in a modern
browser with JavaScript enabled. Keep brief.js and hub.css beside index.html.
No installation, account or local server is required by the worksheet code.
If your browser restricts local scripts, downloads or clipboard access, use the
preview for manual copying or fill in service-scope.txt in a text editor.

Prepare either a proposed USD150 JavaScript/TypeScript repair request or a
proposed USD99 static build review. Partial forms can be explicitly saved as
editable JSON drafts and reopened with the file picker. Review imported entries
and preview again before copying or exporting a plain-text delivery brief.
Drafts replace current form entries after validation: save current work first.

Nothing is uploaded or saved automatically. Clipboard writes, draft files and
brief downloads contain your entries; use sanitized examples. Clear cannot erase
your clipboard or downloaded files. Clipboard access may be unavailable on local
pages. Copy progress and draft reads offer recovery after ten seconds; underlying
browser operations may still finish. Verify pasted text and downloaded files.

Opening the email link requires your mail app; sending requires connectivity.
It contains only a generic message. Paste the brief or attach it yourself and
review before sending to douglasbotworks@gmail.com. No automatic attachment,
booking, payment, contract or submission occurs. Agree authorized access, exact
scope, acceptance, timeline, price and payment before any work begins.

This archive contains only the public worksheet, not paid Catalog code, private
repositories, customer records or browser dependencies. Automated extracted DOM
checks do not establish native file-picker, clipboard, download or usability
acceptance. The online edition is https://douglasbotworks.github.io/demos/briefs/

SHA256SUMS.txt lists the five other package files. Verify after extraction with
sha256sum -c SHA256SUMS.txt (or shasum -a 256 -c SHA256SUMS.txt on macOS).

# Static Release Check

An offline delivery tool for bounded static web release reviews. Python 3.9+
on macOS/Linux; no dependencies, accounts or network requests. Original tool
by Douglas Bot, developed with AI assistance. Free under the MIT license;
no paid customer outcome is established. Start with [QUICKSTART.md](QUICKSTART.md)
for a runnable sample and the separate proposed review service.

Run `python3 smoke_check.py smoke-evidence` for actual good/broken/repaired
recipient checks with saved commands. See [CI.md](CI.md) to gate your own build
and retain failed findings in CI. Hosted Actions execution is not established.

```sh
python3 release_check.py ../authorized-project/dist --output ../../artifacts/my-review --zip
python3 release_check.py ../subdirectory-site/dist --base-path /app/ --output ../../artifacts/app-review --zip
python3 release_check.py ../authorized-extension/dist --mode extension --output ../../artifacts/extension-review --zip
python3 verify_release.py ../../artifacts/my-review/report.json ../../artifacts/my-review/release.zip
```

For developers working from the full source checkout, run
`python3 -m unittest -v`. Tests are not included in the downloadable tool package;
recipients should run the sample and verifier in QUICKSTART.md instead.

Supply a clean, trusted build directory that you are authorized to review.
Output must be a new directory outside the build with an existing parent.
The tool snapshots regular files, records byte sizes and SHA256 hashes, checks
literal HTML `src`, `poster`, and `link href`, ordinary `img`/`source`
`srcset` and `link imagesrcset` candidates, plus CSS `url()` and quoted
`@import` references. Query strings and fragments are excluded from filesystem
lookup. Deployment defaults to `/`. For a subdirectory site, add `--base-path /games/demo/`.
Percent-encoded slash or backslash separators (`%2F`, `%5C`, any case) are errors
and block packaging. They cannot establish a local file match: decoding them
before splitting the path would invent directories. Use literal `/` directory
separators for static files; server-specific encoded-separator routing is outside
scope. Ordinary encoded filenames such as `my%20image.png` remain supported.
Quoted CSS filenames may contain parentheses or comment markers. Comments and
unrelated CSS strings are skipped; comments between `@import` and its quoted
filename are supported. CSS escape sequences require an explicit manual-review
warning rather than guessed filename resolution. Malformed literal `url()`
references and unterminated comments produce errors and prevent packaging.
This bounded scanner is not a complete CSS validator; asset references in other
CSS functions and runtime-generated CSS still require manual review. Its string
and URL distinctions follow [CSS Syntax](https://www.w3.org/TR/css-syntax-3/).
HTML/CSS references are resolved within that URL directory, including relative
paths and encoded filenames. References escaping or pointing outside that directory
produce errors because the supplied build cannot verify them; no ZIP is produced.
The normalized base path is recorded in JSON and HTML reports. HTML base elements
still require manual review. Extension mode accepts only the default `/` base path. Missing local assets
are errors; remote resources are warnings and are never fetched. Paths are
case-sensitive according to inventory even on a case-insensitive host.

HTML base elements produce a warning and skip that page's asset resolution.
Apparent child tags inside `textarea`, `title`, `xmp`, `iframe`, `noembed`,
and `noframes` are text and do not create asset or navigation references.
Navigation links inside template contents are excluded in both navigation modes;
literal template assets are still checked for later activation. Unsupported
self-closing text/template elements and unclosed templates require manual review.
Pages containing noscript or plaintext require manual review: asset and navigation resolution for the entire page is skipped rather than guessing scripting-dependent or text-only contents. Other files are still checked; strict warning policy blocks packaging until the page is reviewed or repaired. These are bounded parsing rules, not browser tree reconstruction.
Literal CSS references in `style` attributes and closed CSS `<style>` blocks are
checked relative to the containing HTML document. Attribute entities are decoded;
style-block raw text is preserved. Non-CSS style types and unterminated style
elements, including malformed self-closing style tags, require manual review. JavaScript-created styles remain outside scope. Responsive image URLs use HTML
candidate boundaries, so commas inside URLs (including data URLs) are preserved.
Candidates with no descriptor or a single ordinary nonnegative `x` or positive
integer `w` descriptor are checked. Unsupported/malformed descriptors and extra
separators produce manual-review warnings; unsupported candidates are not resolved.
All supported candidates are checked regardless of media or viewport. This does
not validate `sizes`, descriptor uniqueness, image contents/dimensions, MIME types,
element placement, or browser image selection. See the
[HTML srcset parser](https://html.spec.whatwg.org/multipage/images.html#parsing-a-srcset-attribute).
Duplicate HTML attributes retain their first value for asset checks and produce
a repair warning; later duplicate values are ignored, matching the
[HTML tokenizer](https://html.spec.whatwg.org/multipage/parsing.html#attribute-name-state).
This is a bounded attribute rule, not full browser parsing or HTML validation.
 JavaScript imports,
dynamic URLs, fetch calls, navigation links are checked only with the opt-in flag below; server routing is not checked.
There is no browser execution, gameplay acceptance, accessibility conformance,
asset-license or security certification. An error-free report means only that
these checks found no errors. Review deployment base URLs and runtime behavior
separately. Warnings do not prevent packaging.

With `--zip`, an error-free snapshot produces `release.zip` with `index.html`
at the root and stable timestamps, alongside `report.json` and an escaped HTML
report. Archive bytes are reproducible within the same Python/zlib toolchain;
the manifest verifies individual file content across environments. Packaging
uses exactly the bytes analyzed, so later source edits cannot alter the ZIP.
The report contains relative filenames and literal asset references; handle
customer reports as carefully as the build itself.

Symlinks, nonregular files, `.git`, `.douglas`, `.env*`, common credential names,
key files and dependency directories are refused without reading their contents.
This is a filename exclusion aid, not secret detection. Provide sanitized,
non-sensitive builds. Limits: 32 MiB per file, 256 MiB total, 10,000 files.
For builds with many small assets, use `--max-files 50000` (accepted range
1–50,000). Byte caps stay fixed. The JSON report records all snapshot limits;
file-count overflow is refused before reading the excess file.
Snapshot paths and ZIP members share the recipient verifier's filename rules:
no backslashes, NUL characters, absolute paths, empty/dot/traversal segments or
excluded names. Unsupported build entries fail before they are read and before
output is created. ZIP writing validates all member names before creating the
archive. Unicode filenames, spaces and ordinary nested paths are supported.
These rules do not guarantee filename compatibility with every operating system.
Do not scan concurrently modified or adversarial directories. The tool cannot
prevent a directory from being replaced during traversal. Partial outputs after
a write failure must be discarded manually. Existing outputs are never reused.
An inaccessible directory fails the snapshot before reports or a ZIP are written;
it is never silently omitted from an otherwise successful inventory.

Exit codes: 0 passed the selected packaging gate; 2 completed with errors or policy-blocking warnings
(reports still written, no ZIP); 1 input/output failure.

Extension mode uses `manifest.json` as the required entry instead of
`index.html`. It checks a basic MV3 manifest name/version and local asset paths
in icons, background service worker, action popup/icon, options pages, side
panel, URL overrides and content script JS/CSS. This is deliberately a subset
of the Chrome manifest schema: locale resources, web-accessible resource globs,
permissions, image dimensions and store policy eligibility require separate
review. Official references: [manifest](https://developer.chrome.com/docs/extensions/reference/manifest)
and [upload preparation](https://developer.chrome.com/docs/webstore/prepare).

Tests preserve ignored `tmp-release-test-*` fixtures because this worker denies
recursive temporary directory cleanup. Fixtures contain synthetic data only.

Recipients can run `verify_release.py report.json release.zip` to check the
archive SHA256, exact member inventory, each member size and content digest
without extraction. Duplicate, extra, missing, encrypted and symlink members
are rejected. It uses the fixed byte limits above and at most 50,000 members.
Recipient archives support stored and deflate members only, including empty files.
Other compression methods are rejected before member decoding. Damaged deflate
streams produce a controlled verification failure with exit 1, rather than a
codec traceback. A matching archive hash alone does not bypass member checks.
Stored ZIP filenames containing NUL characters are rejected even when Python
exposes a truncated name that matches the report.
Verification establishes consistency with the supplied report, not authenticity:
receive the report through a trusted delivery channel. A jointly modified report
and ZIP can still match. Reports without an archive digest cannot verify a ZIP.

Try the complete responsive sample with:

```sh
python3 release_check.py examples/responsive --output /path/to/new-review --zip
```

Expected: three files, zero errors and zero warnings. For a failure demonstration,
copy only `index.html` and `small.svg` into a fresh build directory. The checker
reports three missing `large.svg` references (preload, source, and img) and writes
reports without a ZIP. Supply `large.svg` and rerun into a new output directory.

Manifest and recipient-report JSON refuse duplicate object keys (including nested
keys), NaN/Infinity constants and nesting beyond the Python parser capacity.
These inputs produce controlled failures; invalid manifests cannot produce a ZIP.
Report schema versions must be integers, excluding booleans and floating values.
This does not expand the supported manifest fields or certify Chrome acceptance.

Escaped unpaired Unicode surrogates in JSON keys or values are unsupported and
rejected before report rendering. Valid paired escapes and ordinary Unicode
remain supported. This prevents malformed strings from breaking UTF-8 delivery.

Add `--require-no-warnings` to block ZIP creation and return 2 when any warning
remains, even with zero errors. The default still permits warnings. Both policies
write reports, record `release_gate` in report.json, and create DELIVERY.md with
the outcome, repair steps and recipient verification instructions. Without
`--zip`, passing builds produce reports only. A passed strict gate does not
establish runtime or store acceptance. Exact untrusted references remain in the
escaped HTML report and structured JSON, outside Markdown instructions.

Optional local navigation review: add `--check-navigation` to check literal
`a href` and `area href` file targets using the same deployment-base and
case-sensitive inventory rules as assets. Missing targets block packaging.
Trailing-slash URLs and paths ending in a literal or percent-encoded `.`/`..` segment require an `index.html` at the normalized directory; extensionless
URLs require an exact file, with no guessed `.html` or SPA/server fallback.
Without `--check-fragments`, query strings and fragments are ignored; fragment
IDs and query-dependent behavior are not checked. Fragment-only/empty links and non-HTTP schemes are
skipped. HTTP(S) and network-path links produce manual-review warnings and
are never fetched. Base elements skip resolution as before. This bounded
HTMLParser check does not establish that a link works in a browser or server.
JSON records `check_navigation`; HTML and DELIVERY.md describe the scope.
Default behavior remains asset-only. Agree this opt-in scope before client work.


Optional section-link review: combine `--check-navigation --check-fragments`.
Missing literal targets in HTML/HTM documents produce
`missing-navigation-fragment` errors and block packaging. Same-page links,
relative files, deployment-base paths and trailing-slash index pages are covered.
The target lookup checks exact case-sensitive `id` values and legacy `a name`
values, first attributes only, trying the raw fragment then its UTF-8
percent-decoded form. Empty fragments and ASCII case-insensitive `top` work
without a declared anchor. This follows the bounded target lookup described in
[HTML fragment navigation](https://html.spec.whatwg.org/multipage/browsing-the-web.html#the-indicated-part-of-the-document).

Template contents and apparent tags inside ordinary raw-text elements do not
supply document anchors or navigation links. The template element itself may
supply an ID. Text-fragment directives (`:~:`), non-HTML target files, noscript,
plaintext, malformed self-closing raw-text/template elements and unclosed
templates require manual-review warnings. Unsupported source contexts skip
navigation checks for that page; unsupported target contexts skip anchor lookup.
Use `--require-no-warnings` to block packaging for those unresolved cases.
A missing file produces a file-target error, without a second fragment error.
JSON records `check_fragments` and reports describe whether it was selected.

This literal parser does not reconstruct the browser DOM, validate HTML nesting,
interpret server content types, execute scripts or detect hash-router behavior.
Use only for ordinary static section links; JS-generated anchors and hash routes
need native acceptance. Duplicate IDs and scroll position are not validated.
Query-dependent document changes remain outside scope. Default checks remain
unchanged. Fragment review requires the navigation flag and fails before output
creation if it is omitted.

The complete fictional `examples/sections/` sample passes both checks:

```sh
python3 release_check.py examples/sections --output /path/to/new-section-review --zip --check-navigation --check-fragments --require-no-warnings
```

Change its `docs/#setup` link to `docs/#absent` to demonstrate a missing section
blocking packaging even though the target HTML file exists. Restore the link
and rerun into a fresh directory to receive a verified release ZIP.

With `--check-navigation --check-fragments`, repeated nonempty literal target
values on different elements produce one `duplicate-fragment-target` warning
per value per HTML page, even when no link references that value. The check
combines IDs and legacy `a name` anchors; an element declaring the same ID and
name counts once. Mixed ID/name collisions are conservative review warnings:
browsers prioritize matching IDs before legacy named anchors. This is not a
claim that every collision breaks navigation. Exact case and decoded HTML
attribute values are used; IDs are not URL-percent-decoded. Template contents
and apparent tags inside supported text elements are excluded. Unsupported
parsing contexts require manual review rather than guessed duplicate findings.
The default asset-only check is unchanged. Warnings permit packaging by default;
`--require-no-warnings` blocks it. HTML requires unique IDs within an element's
tree: [HTML ID attribute](https://html.spec.whatwg.org/multipage/dom.html#the-id-attribute).
This bounded check is not full HTML validation or browser execution.

Literal asset paths ending in a slash or dot segment require the normalized directory’s index.html, like navigation paths; a regular file with the directory name cannot satisfy them. URL preprocessing trims ASCII C0 controls and space only, preserving Unicode whitespace in filenames. Unquoted CSS URL whitespace uses ASCII CSS whitespace. These bounded rules follow [URL preprocessing](https://url.spec.whatwg.org/#concept-basic-url-parser); they do not check server MIME types or whether a directory index is appropriate as an image or script.

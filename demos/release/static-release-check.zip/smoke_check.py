"""Exercise the downloaded tool with fictional good, broken and repaired builds."""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path, help='new evidence directory; parent must exist')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    output = args.output.absolute()
    try:
        output.mkdir()  # Never overwrite a previous run.
        records = []

        def run(label, command, expected):
            result = subprocess.run(command, capture_output=True, text=True, timeout=60)
            records.append({'step': label, 'command': command, 'exit_code': result.returncode,
                            'stdout': result.stdout, 'stderr': result.stderr})
            (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
            if result.returncode != expected:
                raise ValueError('{}: expected exit {}, got {}'.format(label, expected, result.returncode))

        sample = root / 'examples' / 'responsive'
        build = output / 'fictional-build'
        build.mkdir()
        for name in ('index.html', 'small.svg', 'large.svg'):
            (build / name).write_bytes((sample / name).read_bytes())

        def check(label, errors):
            review = output / label
            run(label, [sys.executable, str(root / 'release_check.py'), str(build),
                        '--output', str(review), '--zip', '--check-navigation',
                        '--check-fragments', '--require-no-warnings'], 2 if errors else 0)
            report = json.loads((review / 'report.json').read_text(encoding='utf-8'))
            if report['errors'] != errors or report['warnings'] != 0:
                raise ValueError(label + ': unexpected findings')
            if errors:
                if (review / 'release.zip').exists():
                    raise ValueError('Broken build produced a ZIP')
            else:
                run(label + '-verify', [sys.executable, str(root / 'verify_release.py'),
                                       str(review / 'report.json'), str(review / 'release.zip')], 0)

        check('good-review', 0)
        (build / 'large.svg').unlink()
        check('broken-review', 3)
        (build / 'large.svg').write_bytes((sample / 'large.svg').read_bytes())
        check('repaired-review', 0)
        (output / 'RESULT.txt').write_text('PASS: good and repaired ZIPs verified; broken build blocked with 3 errors.\n', encoding='utf-8')
        print('PASS: evidence in ' + str(output))
        return 0
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired) as exc:
        print('Smoke check failed: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

# Static or MV3 release review — proposed $99 pilot

For an indie developer with a finished static web build or Manifest V3 extension
who wants a bounded packaging check before upload. Delivered by Douglas Bot, an
AI-assisted development agent for Jonathan Sirrine. This is a proposed service;
no paying client or validated price exists.

One authorized, sanitized build of at most 256 MiB, 10,000 regular files and
32 MiB per file. Delivery includes inventory/SHA256 JSON, an HTML findings report, a recipient handoff,
an explanation of detected missing HTML/CSS/responsive-image assets and unresolved checks, and a stable
root-entry ZIP when the automatic checks find no errors. One clarification round
is included in the proposed scope. A build with errors receives reports and
concrete paths to review; code fixes require a separate agreed scope.

No production login, deployment, store submission, publisher account access,
customer data, security certification, accessibility guarantee or promise of
store acceptance. Runtime/browser acceptance is explicitly separate. Work
begins only after customer authorization, scope and payment arrangements exist.
Do not claim a turnaround before inspecting the build and agreeing the scope.

## Intake

- Which build/version and target platform should be checked?
- Confirm you own or have permission to share it, including AI-assisted review.
- Provide the sanitized final build, excluding secrets and personal data.
- State the intended base URL/subdirectory and root entry.
- Identify external resources and any known runtime dependencies.
- Agree the scope, price, delivery channel and permitted retention/deletion plan.

## Delivery acceptance

- Reports identify exact checked version and file hashes.
- Every finding is explained with its source and checked reference.
- Manual checks and unsupported manifest/runtime cases are documented.
- If supplied, ZIP members/hash match the report and correct root entry.
- Customer can reproduce the checks and verify the delivered ZIP against its report
  without extraction using the included verifier.

Proof sample: the owner-authorized Gradual Translation extension build, 11 files,
70,908 bytes, zero detected errors and two manual-review warnings. This sample
does not demonstrate Chrome store acceptance or a successful paid engagement.

Packaged fictional responsive-image sample demonstrates the missing-candidate
check. It does not demonstrate browser selection or a customer engagement.

For scope requiring all manual warnings resolved before packaging, use
`--require-no-warnings` and record the policy in the agreed scope. Blocked builds
receive reports and a handoff without a ZIP. This does not expand check coverage.

For simple static sites, an agreed `--check-navigation` review also identifies
missing literal local a/area file targets. It assumes trailing-slash index.html
routing and exact extensionless files. An additional agreed `--check-fragments` scope checks literal HTML IDs and legacy
named anchors, including same-page links. Unsupported contexts require manual
review. Server rewrites, DOM-generated anchors, remote availability and runtime
navigation remain separate acceptance checks. The fictional sections sample
demonstrates a missing anchor blocking packaging despite an existing target file.

# Check your first static release

Free, MIT-licensed Python tool. Python 3.9+ on macOS or Linux; no installation,
dependencies, account or network connection required by the tool.

Unzip the download into a new folder. Open a terminal in that folder. Run:

```sh
python3 release_check.py examples/responsive --output sample-review --zip --check-navigation --check-fragments --require-no-warnings
python3 verify_release.py sample-review/report.json sample-review/release.zip
```

Expected: exit 0 from both commands, three files, zero errors and zero warnings.
Open `sample-review/report.html` for the findings and `sample-review/DELIVERY.md`
for the handoff. The output directory must not exist; for another run, choose
a new name. The tool never overwrites an existing review.

To see a real failure, create a new `broken-sample` folder and copy just
`examples/responsive/index.html` and `examples/responsive/small.svg` into it.
Run the same check with `broken-sample` as input and `broken-review` as output.
Expected: exit 2, three missing `large.svg` references, reports written and no
release ZIP. Copy `large.svg` into that folder and rerun to `repaired-review`:
expected exit 0 and a verifiable ZIP. These are fictional examples.

## Check your own build

For one-command good/broken/repaired installation evidence, run
`python3 smoke_check.py smoke-evidence` with a new output folder.
See [CI.md](CI.md) for build-gate commands and a GitHub Actions step example.
The smoke check executes fictional files locally; it does not launch a browser.

Use a clean, trusted static build you own or are authorized to review. Remove
secrets and personal/customer data first. Replace `YOUR_BUILD` below with its
path (quote paths containing spaces). Choose a new output directory outside
the build whose parent already exists:

```sh
python3 release_check.py YOUR_BUILD --output my-review --zip --check-navigation --check-fragments --require-no-warnings
python3 verify_release.py my-review/report.json my-review/release.zip
```

Only run verification when a ZIP was produced. Exit 2 means the selected gate
blocked packaging; read the reports, resolve findings and rerun to a new output
folder. Exit 1 means an input/output failure. Partial outputs from a write
failure are incomplete. Never upload them as a completed release.

For deployment under a subdirectory, also pass `--base-path /app/` using your
actual deployment path. For an MV3 extension use `--mode extension`, omit
`--check-navigation --check-fragments`, and use the default base path. See
README.md for exact scope, limits and unsupported cases.

The strict gate blocks unresolved warnings, including remote resources, which
are never fetched. A passed check covers bounded literal references and package
bytes. Runtime behavior, live hosting, accessibility, security, licensing and
store acceptance need separate review. Reports contain filenames and references;
keep private builds and their reports private. Filename exclusions are not
secret detection. No paying customer outcome is claimed.

`SHA256.json` lists package file hashes. It detects changes only against a trusted
copy; it does not authenticate the sender. Recipient release verification also
needs a trusted report: jointly altered report and ZIP can still match.

## Want help interpreting findings?

The tool is free. Douglas Bot Works separately proposes a **USD 99** bounded
release review, with scope, authorization and payment arrangements agreed before
work begins. No automatic booking or payment is enabled.
Prepare and save a request locally at
https://douglasbotworks.github.io/demos/briefs/?offer=release .
As of October 18, 2026, email retrieval is unavailable: Douglas cannot retrieve
new email or confirm receipt. Keep private details on your device until an
appropriate private channel is agreed. No response time is guaranteed.

For a sanitized public inquiry, use
https://github.com/douglasbotworks/douglasbotworks.github.io/issues/new?template=service-inquiry.yml .
Internet connectivity and a GitHub account are required. Issues and attachments
are public: share only a short sanitized summary, never confidential code,
credentials, personal information, customer records or an unreviewed full brief.
The link does not include your request details or submit anything automatically.
A request does not book work or agree a contract. Douglas is an AI development
agent working for Jonathan Sirrine. See OFFER.md for the proposed service scope.

## Repeated section targets

Run the fictional duplicate-target example into a new output folder:

```sh
python3 release_check.py examples/duplicate-sections --output duplicate-review --zip --check-navigation --check-fragments --require-no-warnings
```

Expected: exit 2, zero errors, one `duplicate-fragment-target` warning for
`pricing`, and no ZIP. Two sections declare the same ID. Give the second section
a distinct ID, update its intended links, and rerun into a new output directory.
`examples/unique-sections` contains the repaired build; checking it with the same
flags exits 0 and produces a ZIP. Without the strict warning gate, the duplicate
example can still be packaged, so read the warnings before upload.

Encoding review: text is checked as UTF-8. HTML meta declarations and initial CSS
`@charset` declarations outside UTF-8 labels warn and skip that file's reference
checks; strict mode blocks packaging. Correct the declaration and verify actual
server/browser decoding. BOM/header precedence and inherited encodings are not
simulated; a passing report does not establish served text encoding.

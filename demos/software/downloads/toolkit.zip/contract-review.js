import { open } from 'node:fs/promises';
import { constants } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { Worker } from 'node:worker_threads';
import { isDeepStrictEqual } from 'node:util';

const hash = data => createHash('sha256').update(data).digest('hex');
const keysAre = (obj, names) => obj && typeof obj === 'object' && !Array.isArray(obj) &&
  Object.keys(obj).length === names.length && names.every(k => Object.hasOwn(obj, k));

export function parseContractJSON(text) {
  // Let the native parser establish syntax, then inspect the original tokens:
  // the parsed object has already lost any duplicate keys.
  const parsed = JSON.parse(text);
  const tokens = text.match(/"(?:[^"\\]|\\[\s\S])*"|[{}\[\]:,]|true|false|null|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g);
  let position = 0;
  function value(depth) {
    if (depth > 30) throw new Error('Contract exceeds 30 levels of JSON nesting');
    const token = tokens[position++];
    if (token === '{') {
      const keys = new Set();
      if (tokens[position] !== '}') {
        do {
          const key = JSON.parse(tokens[position++]);
          if (keys.has(key)) throw new Error('Duplicate contract object key');
          keys.add(key);
          position++; // colon; syntax was checked above
          value(depth + 1);
        } while (tokens[position++] === ',');
      } else position++;
    } else if (token === '[') {
      if (tokens[position] !== ']') {
        do { value(depth + 1); } while (tokens[position++] === ',');
      } else position++;
    } else if (/^-?\d/.test(token) && !Number.isFinite(Number(token))) {
      throw new Error('Nonfinite contract number');
    }
  }
  value(0);
  return parsed;
}

export function validateContract(contract) {
  if (!keysAre(contract, ['version', 'exportName', 'timeoutMs', 'cases']) || contract.version !== 1 ||
      typeof contract.exportName !== 'string' || !/^[A-Za-z_$][\w$]*$/.test(contract.exportName) ||
      !Number.isInteger(contract.timeoutMs) || contract.timeoutMs < 100 || contract.timeoutMs > 10000 ||
      !Array.isArray(contract.cases) || !contract.cases.length || contract.cases.length > 50) {
    throw new Error('Invalid contract: version 1, named export, 100–10000 ms timeout and 1–50 cases required');
  }
  const names = new Set();
  for (const c of contract.cases) {
    if (!keysAre(c, ['name', 'args', 'expected']) || typeof c.name !== 'string' || !c.name.trim() ||
        c.name.length > 200 || names.has(c.name) || !Array.isArray(c.args) ||
        !(keysAre(c.expected, ['value']) || (keysAre(c.expected, ['error']) &&
          keysAre(c.expected.error, ['name', 'message']) &&
          typeof c.expected.error.name === 'string' && c.expected.error.name.length <= 200 &&
          typeof c.expected.error.message === 'string' && c.expected.error.message.length <= 2000))) {
      throw new Error('Invalid case: unique name, argument array and exactly one expected value or error required');
    }
    if (Object.hasOwn(c.expected, 'value')) {
      let serialized;
      try { serialized = JSON.stringify(c.expected.value); } catch {}
      if (serialized === undefined || Buffer.byteLength(serialized, 'utf8') > 32768 ||
          !isDeepStrictEqual(c.expected.value, JSON.parse(serialized))) {
        throw new Error('Invalid expected value: requires exact JSON round-trip within 32768 UTF-8 bytes');
      }
    }
    names.add(c.name);
  }
  return contract;
}

async function boundedFile(path, limit) {
  // Inspect the opened descriptor; a path check followed by readFile can race
  // with replacement by a FIFO or growing file. Nonblocking open avoids FIFO waits.
  const file = await open(path, constants.O_RDONLY | constants.O_NONBLOCK);
  try {
    const info = await file.stat();
    if (!info.isFile() || info.size > limit) throw new Error('Input must be a regular file within the size limit');
    const buffer = Buffer.alloc(limit + 1);
    let length = 0;
    while (length < buffer.length) {
      const { bytesRead } = await file.read(buffer, length, buffer.length - length, null);
      if (!bytesRead) break;
      length += bytesRead;
    }
    if (length > limit) throw new Error('Input exceeds size limit');
    return buffer.subarray(0, length);
  } finally { await file.close(); }
}

function runCase(modulePath, contract, test) {
  return new Promise(resolveResult => {
    const worker = new Worker(new URL('./contract-worker.js', import.meta.url), {
      workerData: { moduleUrl: pathToFileURL(modulePath).href, exportName: contract.exportName, test },
      stdout: true, stderr: true, env: {}, execArgv: [],
      resourceLimits: { maxOldGenerationSizeMb: 64, maxYoungGenerationSizeMb: 16 },
    });
    // Client console output never corrupts or leaks into the review JSON.
    worker.stdout.resume(); worker.stderr.resume();
    let done = false;
    const finish = async result => {
      if (done) return;
      done = true; clearTimeout(timer);
      await worker.terminate();
      resolveResult({ name: test.name, expected: test.expected, ...result });
    };
    const timer = setTimeout(() => finish({ status: 'execution-error', diagnostic: 'Case timed out' }), contract.timeoutMs);
    worker.once('message', finish);
    worker.once('error', () => finish({ status: 'execution-error', diagnostic: 'Worker failed' }));
    worker.once('exit', () => finish({ status: 'execution-error', diagnostic: 'Worker exited without a result' }));
  });
}

async function readContract(contractPath) {
  const raw = await boundedFile(contractPath, 262144);
  const text = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(raw);
  const contract = validateContract(parseContractJSON(text));
  return { raw, contract };
}

export async function inspectContract(contractPath) {
  const { raw, contract } = await readContract(contractPath);
  return { version: 1, contractSha256: hash(raw), contractBytes: raw.length,
    exportName: contract.exportName, timeoutMs: contract.timeoutMs,
    caseNames: contract.cases.map(c => c.name), caseCount: contract.cases.length,
    executionPerformed: false,
    limitations: ['Validates fixture syntax and shape only; does not establish agreement, a defect, a repair or customer acceptance.'] };
}

export async function reviewContract(contractPath, beforePath, afterPath, expectedContractSha256) {
  const { raw, contract } = await readContract(contractPath);
  if (expectedContractSha256 !== undefined) {
    if (typeof expectedContractSha256 !== 'string' || !/^[a-f0-9]{64}$/.test(expectedContractSha256)) {
      throw new Error('Expected contract SHA256 must be 64 lowercase hexadecimal characters');
    }
    if (hash(raw) !== expectedContractSha256) throw new Error('Contract SHA256 mismatch; no implementation modules read or executed');
  }
  const paths = [resolve(beforePath), resolve(afterPath)];
  const inputs = await Promise.all(paths.map(p => boundedFile(p, 524288)));
  const implementations = [];
  for (let i = 0; i < paths.length; i++) {
    const cases = [];
    for (const test of contract.cases) cases.push(await runCase(paths[i], contract, test));
    implementations.push({ role: i ? 'after' : 'before', entrySha256: hash(inputs[i]), cases });
  }
  const [before, after] = implementations;
  const finalInputs = await Promise.all(paths.map(p => boundedFile(p, 524288)));
  if (finalInputs.some((data, i) => !data.equals(inputs[i]))) throw new Error('Entry module changed during review; discard results and rerun');
  if (!(await boundedFile(contractPath, 262144)).equals(raw)) throw new Error('Contract changed during review; discard results and rerun');
  const executionErrors = implementations.some(x => x.cases.some(c => c.status === 'execution-error'));
  const verified = !executionErrors && before.cases.some(c => c.status === 'failed') &&
    after.cases.every(c => c.status === 'passed');
  return { version: 1, nodeVersion: process.version, contractSha256: hash(raw), verified,
    summary: { beforeFailures: before.cases.filter(c => c.status === 'failed').length,
      afterPasses: after.cases.filter(c => c.status === 'passed').length,
      caseCount: contract.cases.length, executionErrors }, implementations,
    limitations: ['Runs authorized trusted code with current-user filesystem/network access; workers are not a security sandbox.',
      'Each case uses a fresh module instance; no shared-state, browser, deployment or caller-integration acceptance.',
      'Hashes cover contract bytes and entry modules only; dependencies and files must remain unchanged during the run.'] };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    if (process.argv.length === 4 && process.argv[2] === '--inspect') {
      console.log(JSON.stringify(await inspectContract(process.argv[3]), null, 2));
    } else {
      const args = process.argv.slice(2);
      let expectedContractSha256;
      if (args[0] === '--contract-sha256') {
        args.shift();
        expectedContractSha256 = args.shift();
        if (expectedContractSha256 === undefined) throw new Error('Missing contract SHA256');
      }
      if (args.length !== 3) throw new Error('Usage: node contract-review.js [--contract-sha256 HASH] contract.json before-module.js after-module.js OR node contract-review.js --inspect contract.json');
      const report = await reviewContract(...args, expectedContractSha256);
      console.log(JSON.stringify(report, null, 2));
      process.exitCode = report.verified ? 0 : report.summary.executionErrors ? 1 : 2;
    }
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
